# -*- coding: utf-8 -*-
"""
H-File Tool Suite – App tích hợp Module 1 (Struct) + Module 3 (Define).

Cách chạy:
    python app_main.py

Yêu cầu:
    Python 3.9.5
    pip install openpyxl
"""
from __future__ import annotations

from pathlib import Path
from typing import Optional

import tkinter as tk
from tkinter import filedialog, messagebox, ttk

try:
    from openpyxl import load_workbook
except ImportError:
    root = tk.Tk(); root.withdraw()
    messagebox.showerror("Thiếu thư viện", "Chưa cài openpyxl.\n\npython -m pip install openpyxl")
    raise

from common import (
    DEFAULT_SHEET_NAME, PALETTE, FONT_UI, FONT_BOLD, FONT_MONO, FONT_HEAD,
    open_path_in_os, script_dir,
)
from module1_struct import (
    STRUCT_CACHE_FILE, BLOCK_COLUMNS, TARGET_FILE_PATH_CELL, BLOCK_CELL,
    read_defaults_from_workbook, StructTab,
)
from module3_define import (
    DEFINE_CACHE_FILE, DEFINE_NAME_DEFAULT_PATH_CELL,
    read_default_source_path_from_workbook, DefineTab,
)

APP_TITLE   = "H-File Tool Suite  —  Module 1: Struct  +  Module 3: Define"
TOOL_VERSION = "v1_integrated_2026_05_26"


# ---------------------------------------------------------------------------
# Style setup
# ---------------------------------------------------------------------------

def setup_styles(root: tk.Tk) -> None:
    style = ttk.Style(root)
    try:
        if "clam" in style.theme_names():
            style.theme_use("clam")
    except Exception:
        pass

    P = PALETTE

    # ── Frame / Label ────────────────────────────────────────────────────
    style.configure("TFrame",         background=P["bg"])
    style.configure("TLabel",         background=P["bg"], font=FONT_UI, foreground=P["text"])
    style.configure("Muted.TLabel",   background=P["bg"], font=FONT_UI, foreground=P["muted"])

    # ── LabelFrame (card style) ──────────────────────────────────────────
    style.configure("Card.TLabelframe",
        background=P["surface"], bordercolor=P["border"],
        relief="solid", borderwidth=1, padding=8,
    )
    style.configure("Card.TLabelframe.Label",
        font=FONT_BOLD, background=P["surface"], foreground=P["navy"],
    )

    # ── Entry / Combobox ─────────────────────────────────────────────────
    style.configure("TEntry",    font=FONT_MONO, padding=(4, 3), fieldbackground=P["surface"])
    style.configure("TCombobox", font=FONT_UI,   fieldbackground=P["surface"])

    # ── Checkbutton ──────────────────────────────────────────────────────
    style.configure("TCheckbutton", background=P["bg"], font=FONT_UI)

    # ── Separator ────────────────────────────────────────────────────────
    style.configure("TSeparator", background=P["border"])

    # ── Buttons ──────────────────────────────────────────────────────────
    style.configure("TButton",
        font=FONT_UI, padding=(10, 5),
        background=P["surface"], foreground=P["text"], bordercolor=P["border"],
        relief="solid", borderwidth=1,
    )
    style.map("TButton",
        background=[("active", P["bg"]), ("disabled", "#E2E8F0")],
        foreground=[("disabled", P["muted"])],
    )
    style.configure("Accent.TButton",
        font=FONT_BOLD, padding=(12, 6),
        background=P["blue"], foreground="white",
        bordercolor=P["blue"], relief="solid", borderwidth=0,
    )
    style.map("Accent.TButton",
        background=[("active", P["blue_lt"]), ("disabled", P["border"])],
        foreground=[("disabled", P["muted"])],
    )
    style.configure("Success.TButton",
        font=FONT_BOLD, padding=(12, 6),
        background=P["green"], foreground="white",
        bordercolor=P["green"], relief="solid", borderwidth=0,
    )
    style.map("Success.TButton",
        background=[("active", "#15803D"), ("disabled", P["border"])],
        foreground=[("disabled", P["muted"])],
    )

    # ── Progressbar ──────────────────────────────────────────────────────
    style.configure("TProgressbar",
        troughcolor=P["border"], background=P["blue"], thickness=6,
    )

    # ── Treeview ─────────────────────────────────────────────────────────
    style.configure("Treeview",
        font=FONT_UI, rowheight=22,
        background=P["surface"], fieldbackground=P["surface"], foreground=P["text"],
        borderwidth=0,
    )
    style.configure("Treeview.Heading",
        font=FONT_BOLD, background=P["navy"], foreground="white",
        relief="flat", padding=(6, 4),
    )
    style.map("Treeview",
        background=[("selected", P["blue"])],
        foreground=[("selected", "white")],
    )
    style.map("Treeview.Heading",
        background=[("active", "#1E3A5F")],
    )

    # ── Notebook ─────────────────────────────────────────────────────────
    style.configure("TNotebook",
        background=P["bg"], borderwidth=0, tabmargins=[0, 0, 0, 0],
    )
    style.configure("TNotebook.Tab",
        font=FONT_BOLD, padding=(20, 9),
        background=P["bg"], foreground=P["muted"], borderwidth=0,
    )
    style.map("TNotebook.Tab",
        background=[("selected", P["surface"]), ("active", P["border"])],
        foreground=[("selected", P["navy"])],
        expand=[("selected", [1, 1, 1, 0])],
    )

    # ── Scrollbar ────────────────────────────────────────────────────────
    style.configure("TScrollbar",
        background=P["border"], troughcolor=P["bg"],
        arrowcolor=P["muted"], borderwidth=0, relief="flat",
    )


# ---------------------------------------------------------------------------
# IntegratedApp
# ---------------------------------------------------------------------------

class IntegratedApp(tk.Tk):
    def __init__(self) -> None:
        super().__init__()
        self.title(APP_TITLE)
        self.geometry("1240x860")
        self.minsize(1000, 680)
        self.configure(bg=PALETTE["bg"])

        setup_styles(self)

        self.xlsm_path_var   = tk.StringVar()
        self.source_path_var = tk.StringVar()
        self._run_both_active = False

        self._build_header()
        self._build_shared_inputs()
        self._build_action_bar()
        self._build_notebook()
        self._build_shared_log()
        self._build_status_bar()

    # ── Header ─────────────────────────────────────────────────────────────

    def _build_header(self) -> None:
        cv = tk.Canvas(self, height=58, bg=PALETTE["navy"], highlightthickness=0)
        cv.pack(fill="x")

        # Left accent stripe
        cv.create_rectangle(0, 0, 5, 58, fill=PALETTE["blue"], outline="")

        self._hdr_title = cv.create_text(
            22, 20, anchor="w",
            text="H-File Tool Suite",
            font=("Segoe UI", 14, "bold"), fill=PALETTE["header_fg"],
        )
        self._hdr_sub = cv.create_text(
            22, 40, anchor="w",
            text="Module 1: Trích xuất Struct  ·  Module 3: Triển khai Define  ·  {}".format(TOOL_VERSION),
            font=("Segoe UI", 8), fill=PALETTE["header_sub"],
        )
        self._hdr_ver = cv.create_text(
            1220, 29, anchor="e",
            text="Python 3.9+  |  openpyxl",
            font=("Segoe UI", 8), fill="#475569",
        )
        cv.bind("<Configure>", lambda e: cv.coords(self._hdr_ver, e.width - 16, 29))

    # ── Shared inputs ──────────────────────────────────────────────────────

    def _build_shared_inputs(self) -> None:
        outer = ttk.Frame(self, padding=(12, 8, 12, 0))
        outer.pack(fill="x")

        frame = ttk.LabelFrame(outer, text=" Đầu vào chung ", style="Card.TLabelframe")
        frame.pack(fill="x")

        for row_idx, (label, var, cmd) in enumerate([
            ("📄  File Excel (.xlsm):", self.xlsm_path_var,   self._choose_xlsm),
            ("📁  Thư mục source (.h):", self.source_path_var, self._choose_source_dir),
        ]):
            r = ttk.Frame(frame, style="Card.TLabelframe")
            r.pack(fill="x", pady=(0 if row_idx else 0, 4))
            lbl = tk.Label(r, text=label, width=22, anchor="w",
                           font=FONT_UI, bg=PALETTE["surface"], fg=PALETTE["text"])
            lbl.pack(side="left")
            ttk.Entry(r, textvariable=var, font=FONT_MONO).pack(
                side="left", fill="x", expand=True, padx=6)
            ttk.Button(r, text="Chọn...", command=cmd).pack(side="left")

    # ── Action bar ─────────────────────────────────────────────────────────

    def _build_action_bar(self) -> None:
        bar = ttk.Frame(self, padding=(12, 6, 12, 2))
        bar.pack(fill="x")

        self.run_both_btn = ttk.Button(
            bar, text="⚡  Chạy cả 2 bước liên tiếp",
            command=self._run_both_action, style="Success.TButton",
        )
        self.run_both_btn.pack(side="left", padx=(0, 10))

        sep = tk.Frame(bar, width=1, bg=PALETTE["border"])
        sep.pack(side="left", fill="y", padx=6)

        ttk.Button(bar, text="💾  Cache struct",
                   command=lambda: open_path_in_os(script_dir() / STRUCT_CACHE_FILE)).pack(side="left", padx=4)
        ttk.Button(bar, text="💾  Cache define",
                   command=lambda: open_path_in_os(script_dir() / DEFINE_CACHE_FILE)).pack(side="left", padx=4)

    # ── Notebook ───────────────────────────────────────────────────────────

    def _build_notebook(self) -> None:
        outer = ttk.Frame(self, padding=(12, 4, 12, 0))
        outer.pack(fill="both", expand=True)

        self.notebook = ttk.Notebook(outer)
        self.notebook.pack(fill="both", expand=True)

        # Tab 1 – Struct
        tab1 = ttk.Frame(self.notebook, padding=6)
        self.struct_tab = StructTab(
            tab1, self,
            self.xlsm_path_var, self.source_path_var,
            self.log, self.set_status,
            on_done=self._on_struct_done,
        )
        self.struct_tab.pack(fill="both", expand=True)
        self.notebook.add(tab1, text="  ①  Trích xuất Struct  ")

        # Tab 2 – Define
        tab2 = ttk.Frame(self.notebook, padding=6)
        self.define_tab = DefineTab(
            tab2, self,
            self.xlsm_path_var, self.source_path_var,
            self.log, self.set_status,
            on_done=self._on_define_done,
        )
        self.define_tab.pack(fill="both", expand=True)
        self.notebook.add(tab2, text="  ②  Triển khai Define  ")

    # ── Shared log ─────────────────────────────────────────────────────────

    def _build_shared_log(self) -> None:
        outer = ttk.Frame(self, padding=(12, 4, 12, 0))
        outer.pack(fill="x")

        frame = ttk.LabelFrame(outer, text=" Log ", style="Card.TLabelframe")
        frame.pack(fill="both", expand=False)
        frame.configure(height=130)
        frame.pack_propagate(False)

        self._log_text = tk.Text(
            frame, height=6, wrap="word",
            font=FONT_MONO, bg=PALETTE["surface"], fg=PALETTE["text"],
            relief="flat", bd=0, selectbackground=PALETTE["blue"],
        )
        vsb = ttk.Scrollbar(frame, orient="vertical", command=self._log_text.yview)
        self._log_text.configure(yscrollcommand=vsb.set)
        vsb.pack(side="right", fill="y")
        self._log_text.pack(side="left", fill="both", expand=True)

        # Color tags for log lines
        self._log_text.tag_configure("ok",    foreground=PALETTE["green"])
        self._log_text.tag_configure("warn",  foreground=PALETTE["amber"])
        self._log_text.tag_configure("error", foreground=PALETTE["red"])
        self._log_text.tag_configure("info",  foreground=PALETTE["blue"])
        self._log_text.tag_configure("sep",   foreground=PALETTE["muted"])

    # ── Status bar ─────────────────────────────────────────────────────────

    def _build_status_bar(self) -> None:
        bar = tk.Frame(self, bg=PALETTE["navy"], height=30)
        bar.pack(fill="x", side="bottom")
        bar.pack_propagate(False)

        # Status indicator dot
        self._dot_cv = tk.Canvas(bar, width=14, height=14,
                                  bg=PALETTE["navy"], highlightthickness=0)
        self._dot_cv.pack(side="left", padx=(12, 4), pady=8)
        self._dot_id = self._dot_cv.create_oval(2, 2, 12, 12,
                                                 fill=PALETTE["green"], outline="")

        self._status_lbl = tk.Label(
            bar, text="Sẵn sàng.",
            font=("Segoe UI", 9), bg=PALETTE["navy"], fg="white", anchor="w",
        )
        self._status_lbl.pack(side="left", fill="x", expand=True)

        self._prog_bar = ttk.Progressbar(bar, mode="indeterminate", length=140)
        self._prog_bar.pack(side="right", padx=(4, 12))

        tk.Button(
            bar, text="Xóa Log", font=("Segoe UI", 8),
            bg="#334155", fg="white", relief="flat", bd=0,
            activebackground=PALETTE["blue_lt"], activeforeground="white",
            padx=8, pady=2, cursor="hand2",
            command=self._clear_log,
        ).pack(side="right", padx=(0, 8))

    # ── Shared log / status API ─────────────────────────────────────────────

    def log(self, message: str) -> None:
        mu = message.upper()
        if "[OK]" in mu or "HOÀN TẤT" in mu or "═══" in message:
            tag = "ok"
        elif "[WARN]" in mu or "CẢNH BÁO" in mu:
            tag = "warn"
        elif "[ERROR]" in mu or "[LỖI]" in mu:
            tag = "error"
        elif "[INFO]" in mu or "[STATUS]" in mu:
            tag = "info"
        elif "=" * 10 in message:
            tag = "sep"
        else:
            tag = ""
        self._log_text.insert("end", message + "\n", (tag,) if tag else ())
        self._log_text.see("end")
        self.update_idletasks()

    def set_status(self, message: str, level: str = "normal") -> None:
        self._status_lbl.config(text=message)
        dot_colors = {
            "ok":     PALETTE["green"],
            "error":  PALETTE["red"],
            "warn":   PALETTE["amber"],
            "busy":   PALETTE["blue"],
            "normal": PALETTE["green"],
        }
        self._dot_cv.itemconfig(self._dot_id, fill=dot_colors.get(level, PALETTE["green"]))

    def _clear_log(self) -> None:
        self._log_text.delete("1.0", "end")

    # ── Path choosers ──────────────────────────────────────────────────────

    def _choose_xlsm(self) -> None:
        path = filedialog.askopenfilename(
            title="Chọn file Excel .xlsm",
            filetypes=[("Excel Macro Workbook", "*.xlsm"),
                       ("Excel Workbook", "*.xlsx"),
                       ("All files", "*.*")],
            parent=self,
        )
        if not path:
            return
        self.xlsm_path_var.set(path)
        self.log("[INFO] Đã chọn Excel: {}".format(path))

        # Auto-fill source path from workbook
        try:
            source, block = read_defaults_from_workbook(Path(path))
            if source:
                self.source_path_var.set(source)
                self.log("[OK] Source path từ sheet 操作 D9: {}".format(source))
            if block and block in BLOCK_COLUMNS:
                self.struct_tab.block_var.set(block)
                self.log("[INFO] Block từ sheet 操作 D11: {}".format(block))
        except Exception as exc:
            self.log("[WARN] Không đọc được defaults từ Excel: {}".format(exc))

        # Module 3 path cell is D20
        if not self.source_path_var.get().strip():
            try:
                p = read_default_source_path_from_workbook(Path(path))
                if p:
                    self.source_path_var.set(p)
                    self.log("[OK] Source path từ sheet 操作 D20: {}".format(p))
            except Exception:
                pass

    def _choose_source_dir(self) -> None:
        path = filedialog.askdirectory(title="Chọn thư mục chứa file .h", parent=self)
        if path:
            self.source_path_var.set(path)
            self.log("[INFO] Đã chọn source folder: {}".format(path))

    # ── Run both ───────────────────────────────────────────────────────────

    def _run_both_action(self) -> None:
        if self.struct_tab.is_running() or self.define_tab.is_running():
            messagebox.showwarning("Đang chạy",
                "Một bước đang chạy. Vui lòng chờ hoàn tất.", parent=self)
            return

        xlsm   = self.xlsm_path_var.get().strip()
        source = self.source_path_var.get().strip()
        if not xlsm or not Path(xlsm).exists():
            messagebox.showerror("Thiếu file", "Vui lòng chọn file .xlsm.", parent=self)
            return
        if not source or not Path(source).is_dir():
            messagebox.showerror("Thiếu source", "Vui lòng chọn thư mục source .h.", parent=self)
            return

        ok = messagebox.askyesno(
            "Xác nhận chạy cả 2 bước",
            "Tool sẽ thực hiện liên tiếp:\n\n"
            "  ① Tạo backup → Trích xuất struct vào sheet No*, 抽出構造体リスト\n"
            "  ② Triển khai define/enum → Sheet 配列要素数定義展開リスト\n\n"
            "Bạn muốn tiếp tục?",
            parent=self,
        )
        if not ok:
            return

        self._run_both_active = True
        self.run_both_btn.configure(state="disabled")
        self.notebook.select(0)
        self.log("[INFO] ══════════ BẮT ĐẦU CHẠY CẢ 2 BƯỚC ══════════")
        self.set_status("Đang chạy cả 2 bước...", "busy")
        self._prog_bar.start(12)
        self.struct_tab.start_run(skip_confirm=True)

    def _on_struct_done(self, success: bool) -> None:
        if not self._run_both_active:
            return
        if not success:
            self._run_both_active = False
            self.run_both_btn.configure(state="normal")
            self._prog_bar.stop()
            self.set_status("Dừng sau lỗi Bước 1.", "error")
            return
        self.log("[INFO] Bước 1 hoàn tất. Chuyển sang Bước 2...")
        self.notebook.select(1)
        # Short delay for notebook animation to settle
        self.after(400, self.define_tab.start_run)

    def _on_define_done(self, success: bool) -> None:
        if self._run_both_active:
            self._run_both_active = False
            self.run_both_btn.configure(state="normal")
            self._prog_bar.stop()
            if success:
                self.log("[OK] ══════════ CẢ 2 BƯỚC HOÀN TẤT ══════════")
                self.set_status("Cả 2 bước hoàn tất  ✓", "ok")
            else:
                self.set_status("Lỗi ở Bước 2.", "error")


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def main() -> None:
    app = IntegratedApp()
    app.mainloop()


if __name__ == "__main__":
    main()
