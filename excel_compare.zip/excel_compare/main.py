from gui import ExcelCompareApp

if __name__ == "__main__":
    app = ExcelCompareApp()
    app.mainloop()
