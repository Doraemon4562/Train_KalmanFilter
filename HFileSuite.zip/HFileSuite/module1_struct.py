# -*- coding: utf-8 -*-
"""
Module 1 – Trích xuất typedef struct từ file .h và ghi vào workbook .xlsm.

Logic giữ nguyên từ struct_extractor_gui_module1_v6.py.
GUI được tách thành StructTab(ttk.Frame) để nhúng vào app tích hợp.
"""
from __future__ import annotations

import csv
import os
import queue
import re
import threading
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Callable, Dict, List, Optional, Set, Tuple

import tkinter as tk
from tkinter import filedialog, messagebox, ttk

try:
    from openpyxl import load_workbook
    from openpyxl.styles import Alignment, Font
    from openpyxl.utils import column_index_from_string
except ImportError:
    raise

from common import (
    DEFAULT_SHEET_NAME, IDENT_RE, LINE_COMMENT_RE, MEMBER_DISABLE_MARK,
    MULTI_COMMENT_RE, NO_SHEET_RE, PALETTE, FONT_UI, FONT_BOLD, FONT_MONO,
    load_cache, make_backup, open_path_in_os, read_text_auto, save_cache, script_dir,
    save_workbook_preserve_drawings,
)

# ---------------------------------------------------------------------------
# Module-1 constants
# ---------------------------------------------------------------------------
TOOL_VERSION_M1  = "v4_dfs_level_column_2026_05_25"
STRUCT_CACHE_FILE = "struct_path_cache.json"

SETTING_SHEET_NAME = "設定"
STRUCT_LIST_SHEET  = "抽出構造体リスト"

STRUCT_LIST_TOP_LINE = 2
STRUCT_LIST_TOP_CLM  = 2   # B: struct name
STRUCT_PATH_CLM      = 3   # C: header path
STRUCT_CSW_CLM       = 4   # D: compile switch mark
STRUCT_LEVEL_CLM     = 5   # E: DFS level, root=1
STRUCT_LIST_NO_CLM   = 1   # A: No

TARGET_FILE_PATH_CELL = "D9"
BLOCK_CELL            = "D11"

STRUCT_NAME_CLM              = 1
STRUCT_COMMENT_CLM           = 2
STRUCT_MARK_CLM_IN_SHEET     = 1
STRUCT_IFDEF_CLM_IN_SHEET    = 2
STRUCT_MEMBER_TYPE_CLM_IN_SHEET    = 3
STRUCT_MEMBER_CLM_IN_SHEET         = 4
STRUCT_MEMBER_COMMENT_CLM_IN_SHEET = 5

BLOCK_COLUMNS = {
    "CMN1": "K", "CMN2": "M", "LGT": "O",
    "OBJ1": "Q", "OBJ2": "S", "LNE": "U",
    "PAMDA": "W", "SGN": "Y", "TLR": "AA",
    "RPR": "AC", "TSR": "AE",
}
BLOCK_COLUMN_INDEX = {name: column_index_from_string(col) for name, col in BLOCK_COLUMNS.items()}

BUILTIN_TYPES = {
    "U1","U2","U4","U8","S1","S2","S4","S8",
    "u1","u2","u4","u8","s1","s2","s4","s8",
    "uint8_t","uint16_t","uint32_t","uint64_t",
    "int8_t","int16_t","int32_t","int64_t",
    "UINT8","UINT16","UINT32","UINT64",
    "INT8","INT16","INT32","INT64",
    "BYTE","WORD","DWORD","BOOL","bool","Bool",
    "char","unsigned","signed","short","long","int",
    "float","double","void","size_t",
}
C_KEYWORDS_M1 = {
    "const","volatile","static","extern","register","struct","union","enum",
}

# Module-1 specific regex
STRUCT_CLOSE_RE = re.compile(r"}\s*([A-Za-z_]\w*)\s*;")
COMMENT_RE      = re.compile(r"/\*(.*?)\*/")

# alias for backward compat inside engine
create_backup = make_backup


# ---------------------------------------------------------------------------
# Data models
# ---------------------------------------------------------------------------

@dataclass
class StructMember:
    type_name: str = ""
    member_name: str = ""
    comment: str = ""
    ifdef: str = ""
    disabled_mark: str = ""
    source_line: int = 0
    raw_line: str = ""
    original_type_name: str = ""


@dataclass
class StructCandidate:
    struct_name: str
    file_path: Path
    start_line: int
    end_line: int
    comment: str
    raw_block: str
    member_lines: List[str] = field(default_factory=list)
    member_line_numbers: List[int] = field(default_factory=list)


@dataclass
class ParsedStruct:
    struct_name: str
    file_path: Path
    start_line: int
    end_line: int
    comment: str
    members: List[StructMember]
    has_compile_switch: bool = False
    sub_struct_names: List[str] = field(default_factory=list)


@dataclass
class StructResult:
    no: int
    struct_name: str
    status: str
    level: int = 1
    file_path: str = "-"
    has_compile_switch: bool = False
    sheet_name: str = ""
    message: str = ""


# ---------------------------------------------------------------------------
# Parser helpers
# ---------------------------------------------------------------------------

def _strip_tabs_left(line: str) -> str:
    return line.replace("\t", " ").lstrip()


def _is_comment_only_or_empty(line: str) -> bool:
    s = _strip_tabs_left(line).strip()
    return not s or s.startswith("/*") or s.startswith("//")


def extract_block_comment(line: str) -> str:
    m = COMMENT_RE.search(line)
    return m.group(1).replace("\t", "").strip() if m else ""


def remove_inline_comments_for_parse(line: str) -> str:
    s = COMMENT_RE.sub("", line)
    return LINE_COMMENT_RE.sub("", s)


def scan_struct_candidates_in_file(file_path: Path) -> List[StructCandidate]:
    text, _ = read_text_auto(file_path)
    lines = text.splitlines()
    candidates: List[StructCandidate] = []

    i = 0
    while i < len(lines):
        raw  = lines[i]
        line = _strip_tabs_left(raw)
        if _is_comment_only_or_empty(line) or "typedef struct" not in line:
            i += 1
            continue

        start_idx = i
        raw_block_lines: List[str] = [raw]
        member_lines: List[str] = []
        member_line_numbers: List[int] = []
        seen_open_brace = "{" in line

        if seen_open_brace:
            after = raw.split("{", 1)[1]
            if after.strip() and "}" not in after:
                member_lines.append(after)
                member_line_numbers.append(i + 1)

        j = i + 1
        found_close = False
        while j < len(lines):
            raw_j  = lines[j]
            raw_block_lines.append(raw_j)
            line_j = _strip_tabs_left(raw_j)

            if not seen_open_brace:
                if "{" in line_j:
                    seen_open_brace = True
                    after = raw_j.split("{", 1)[1]
                    if after.strip() and "}" not in after:
                        member_lines.append(after)
                        member_line_numbers.append(j + 1)
                j += 1
                continue

            close_m = STRUCT_CLOSE_RE.search(line_j)
            if close_m:
                candidates.append(StructCandidate(
                    struct_name=close_m.group(1).strip(),
                    file_path=file_path,
                    start_line=start_idx + 1,
                    end_line=j + 1,
                    comment=extract_block_comment(line_j),
                    raw_block="\n".join(raw_block_lines),
                    member_lines=member_lines,
                    member_line_numbers=member_line_numbers,
                ))
                found_close = True
                break

            if not _is_comment_only_or_empty(line_j) and line_j.strip() != "{":
                member_lines.append(line_j)
                member_line_numbers.append(j + 1)
            j += 1

        i = (j + 1) if found_close else (start_idx + 1)

    return candidates


def _normalize_type_and_member(decl: str) -> Tuple[str, str]:
    s = decl.strip()
    if ";" in s:
        s = s.split(";", 1)[0].strip()
    parts = s.split(None, 1)
    if len(parts) == 1:
        return parts[0], ""
    return parts[0].strip(), parts[1].strip()


def _should_queue_sub_struct(type_name: str, original_type_name: str) -> bool:
    if not type_name or not original_type_name:
        return False
    if original_type_name.startswith("EN_"):
        return False
    if type_name in BUILTIN_TYPES or type_name in C_KEYWORDS_M1:
        return False
    if len(type_name) <= 3:
        return False
    return bool(IDENT_RE.match(type_name))


def parse_candidate(candidate: StructCandidate) -> ParsedStruct:
    members: List[StructMember] = []
    sub_structs: List[str] = []
    has_switch = False

    for raw_line, line_no in zip(candidate.member_lines, candidate.member_line_numbers):
        line = _strip_tabs_left(raw_line).strip()
        if not line or line.startswith("/*") or line.startswith("//") or line == "{":
            continue

        if line.startswith(("#if", "#else", "#endif")):
            has_switch = True
            members.append(StructMember(
                ifdef=line, disabled_mark=MEMBER_DISABLE_MARK,
                source_line=line_no, raw_line=raw_line,
            ))
            continue

        if ";" not in line:
            continue

        comment   = extract_block_comment(line)
        line_nc   = remove_inline_comments_for_parse(line)
        type_name, member_name = _normalize_type_and_member(line_nc)
        original  = type_name

        if original.startswith("EN_"):
            type_name = "U4"

        if _should_queue_sub_struct(type_name, original):
            sub_structs.append(original)

        members.append(StructMember(
            type_name=type_name, member_name=member_name, comment=comment,
            source_line=line_no, raw_line=raw_line, original_type_name=original,
        ))

    return ParsedStruct(
        struct_name=candidate.struct_name,
        file_path=candidate.file_path,
        start_line=candidate.start_line,
        end_line=candidate.end_line,
        comment=candidate.comment,
        members=members,
        has_compile_switch=has_switch,
        sub_struct_names=sub_structs,
    )


# ---------------------------------------------------------------------------
# Scanner
# ---------------------------------------------------------------------------

def build_struct_index(
    source_root: Path,
    exclude_dirs: Optional[List[Path]] = None,
    log: Optional[Callable[[str], None]] = None,
) -> Dict[str, List[StructCandidate]]:
    index: Dict[str, List[StructCandidate]] = {}
    exclude_dirs = exclude_dirs or []
    headers = sorted(source_root.rglob("*.h"))

    if exclude_dirs:
        def _excl(p: Path) -> bool:
            for ex in exclude_dirs:
                try:
                    p.relative_to(ex); return True
                except ValueError:
                    pass
            return False
        headers = [h for h in headers if not _excl(h)]

    if log:
        if exclude_dirs:
            log("[INFO] Thư mục loại trừ: {}".format("; ".join(str(d) for d in exclude_dirs)))
        log("Đang quét {} file .h trong: {}".format(len(headers), source_root))

    for idx, header in enumerate(headers, 1):
        try:
            for cand in scan_struct_candidates_in_file(header):
                index.setdefault(cand.struct_name, []).append(cand)
        except Exception as exc:
            if log:
                log("[CẢNH BÁO] Không đọc được: {} ({})".format(header, exc))
        if log and idx % 100 == 0:
            log("Đã quét {}/{} file .h...".format(idx, len(headers)))

    if log:
        total = sum(len(v) for v in index.values())
        log("[OK] Đã tạo index: {} tên struct, {} định nghĩa.".format(len(index), total))
    return index


# ---------------------------------------------------------------------------
# Excel I/O
# ---------------------------------------------------------------------------

def open_workbook_keep_vba(xlsm_path: Path):
    return load_workbook(str(xlsm_path), keep_vba=True)


def read_defaults_from_workbook(xlsm_path: Path) -> Tuple[str, str]:
    wb = open_workbook_keep_vba(xlsm_path)
    try:
        if DEFAULT_SHEET_NAME not in wb.sheetnames:
            return "", ""
        ws      = wb[DEFAULT_SHEET_NAME]
        source  = str(ws[TARGET_FILE_PATH_CELL].value or "").strip()
        block   = str(ws[BLOCK_CELL].value or "").strip()
        return source, block
    finally:
        wb.close()


def read_structs_from_workbook(xlsm_path: Path, block_name: str) -> Tuple[List[str], str]:
    wb = open_workbook_keep_vba(xlsm_path)
    try:
        if SETTING_SHEET_NAME not in wb.sheetnames:
            raise ValueError("Không tìm thấy sheet '{}' trong file Excel.".format(SETTING_SHEET_NAME))
        if block_name not in BLOCK_COLUMN_INDEX:
            raise ValueError("Input/block không hợp lệ: {}".format(block_name))

        ws_s  = wb[SETTING_SHEET_NAME]
        col   = BLOCK_COLUMN_INDEX[block_name]
        structs: List[str] = []
        for row in range(3, ws_s.max_row + 1):
            v = ws_s.cell(row=row, column=col).value
            if v is None:
                continue
            name = str(v).strip()
            if name:
                structs.append(name)

        source = ""
        if DEFAULT_SHEET_NAME in wb.sheetnames:
            v2 = wb[DEFAULT_SHEET_NAME][TARGET_FILE_PATH_CELL].value
            source = str(v2 or "").strip()
        return structs, source
    finally:
        wb.close()


def clear_old_result_sheets(wb) -> None:
    for name in list(wb.sheetnames):
        if NO_SHEET_RE.match(name):
            wb.remove(wb[name])

    if STRUCT_LIST_SHEET in wb.sheetnames:
        ws = wb[STRUCT_LIST_SHEET]
        for row in range(STRUCT_LIST_TOP_LINE, max(ws.max_row, STRUCT_LIST_TOP_LINE) + 1):
            for col in range(1, 6):
                ws.cell(row=row, column=col).value = None
    else:
        wb.create_sheet(STRUCT_LIST_SHEET)

    ws = wb[STRUCT_LIST_SHEET]
    headers = {STRUCT_LIST_NO_CLM: "No", STRUCT_LIST_TOP_CLM: "Struct",
               STRUCT_PATH_CLM: "Path", STRUCT_CSW_CLM: "#if", STRUCT_LEVEL_CLM: "Level"}
    for col, text in headers.items():
        cell = ws.cell(row=1, column=col)
        cell.value = text
        cell.font  = Font(bold=True)


def write_struct_list_row(wb, result: StructResult) -> None:
    ws  = wb[STRUCT_LIST_SHEET]
    row = STRUCT_LIST_TOP_LINE + result.no - 1
    ws.cell(row=row, column=STRUCT_LIST_NO_CLM).value  = result.no
    ws.cell(row=row, column=STRUCT_LIST_TOP_CLM).value = result.struct_name
    ws.cell(row=row, column=STRUCT_PATH_CLM).value     = result.file_path or "-"
    ws.cell(row=row, column=STRUCT_CSW_CLM).value      = "*" if result.has_compile_switch else None
    ws.cell(row=row, column=STRUCT_LEVEL_CLM).value    = result.level
    for col, w in [("A", 8), ("B", 32), ("C", 80), ("D", 10), ("E", 10)]:
        ws.column_dimensions[col].width = w


def write_struct_sheet(wb, no: int, parsed: ParsedStruct) -> str:
    sheet_name = "No{}".format(no)
    if sheet_name in wb.sheetnames:
        wb.remove(wb[sheet_name])
    ws = wb.create_sheet(sheet_name)

    for col, text in [(STRUCT_NAME_CLM, parsed.struct_name),
                      (STRUCT_COMMENT_CLM, parsed.comment),
                      (STRUCT_MEMBER_TYPE_CLM_IN_SHEET, "型"),
                      (STRUCT_MEMBER_CLM_IN_SHEET, "メンバ"),
                      (STRUCT_MEMBER_COMMENT_CLM_IN_SHEET, "コメント")]:
        c = ws.cell(row=1, column=col)
        c.value = text
        c.font  = Font(bold=True)
        c.alignment = Alignment(vertical="center")

    row = 2
    for member in parsed.members:
        if member.ifdef:
            ws.cell(row=row, column=STRUCT_MARK_CLM_IN_SHEET).value  = MEMBER_DISABLE_MARK
            ws.cell(row=row, column=STRUCT_IFDEF_CLM_IN_SHEET).value = member.ifdef
        else:
            ws.cell(row=row, column=STRUCT_MEMBER_TYPE_CLM_IN_SHEET).value    = member.type_name
            ws.cell(row=row, column=STRUCT_MEMBER_CLM_IN_SHEET).value         = member.member_name
            ws.cell(row=row, column=STRUCT_MEMBER_COMMENT_CLM_IN_SHEET).value = member.comment
        row += 1

    for col, w in [("A", 12), ("B", 28), ("C", 28), ("D", 36), ("E", 42)]:
        ws.column_dimensions[col].width = w
    return sheet_name


def save_workbook(wb, xlsm_path: Path) -> None:
    save_workbook_preserve_drawings(wb, xlsm_path)
    wb.close()


# ---------------------------------------------------------------------------
# Extraction Engine (logic giữ nguyên)
# ---------------------------------------------------------------------------

LogFunc            = Callable[[str], None]
ChooseCandidateFunc = Callable[[str, List[StructCandidate], Optional[str]], Optional[StructCandidate]]
ResultFunc         = Callable[[StructResult], None]


class StructExtractionEngine:
    def __init__(
        self,
        xlsm_path: Path,
        source_root: Path,
        initial_structs: List[str],
        cache_path: Path,
        choose_candidate: ChooseCandidateFunc,
        exclude_dirs: Optional[List[Path]] = None,
        use_cache: bool = True,
        log: Optional[LogFunc] = None,
        on_result: Optional[ResultFunc] = None,
    ) -> None:
        self.xlsm_path       = xlsm_path
        self.source_root     = source_root
        self.initial_structs = initial_structs
        self.cache_path      = cache_path
        self.choose_candidate = choose_candidate
        self.exclude_dirs    = exclude_dirs or []
        self.use_cache       = use_cache
        self.log             = log or (lambda _: None)
        self.on_result       = on_result or (lambda _: None)
        self.cache: Dict[str, str]             = load_cache(cache_path)
        self.session_chosen: Dict[str, StructCandidate] = {}
        self.extracted_set: Set[str]           = set()

    def _select_candidate(self, struct_name: str, candidates: List[StructCandidate]) -> Optional[StructCandidate]:
        if not candidates:
            return None
        if struct_name in self.session_chosen:
            chosen = self.session_chosen[struct_name]
            self.log("[SESSION] Dùng lại: '{}' → {}".format(struct_name, chosen.file_path))
            return chosen
        if len(candidates) == 1:
            c = candidates[0]
            self.cache[struct_name] = str(c.file_path)
            self.session_chosen[struct_name] = c
            return c

        cached_path = self.cache.get(struct_name)
        if self.use_cache and cached_path:
            matched = next(
                (c for c in candidates
                 if os.path.normcase(str(c.file_path)) == os.path.normcase(cached_path)),
                None,
            )
            if matched is not None:
                self.log("[CACHE] Tự động chọn: '{}' → {}".format(struct_name, matched.file_path))
                self.session_chosen[struct_name] = matched
                return matched
            self.log("[CẢNH BÁO] Cache không còn hợp lệ cho '{}'.".format(struct_name))

        self.log("[CẦN CHỌN] Struct '{}' xuất hiện trong {} file.".format(struct_name, len(candidates)))
        selected = self.choose_candidate(struct_name, candidates, cached_path)
        if selected is not None:
            self.cache[struct_name] = str(selected.file_path)
            self.session_chosen[struct_name] = selected
        return selected

    def run(self) -> List[StructResult]:
        if not self.xlsm_path.exists():
            raise FileNotFoundError("Không tìm thấy file Excel: {}".format(self.xlsm_path))
        if not self.source_root.exists() or not self.source_root.is_dir():
            raise FileNotFoundError("Không tìm thấy thư mục source: {}".format(self.source_root))
        if not self.initial_structs:
            raise ValueError("Danh sách struct ban đầu đang rỗng.")

        self.session_chosen = {}
        self.extracted_set  = set()

        self.log("Đang tạo backup trước khi ghi đè file Excel...")
        backup_path = create_backup(self.xlsm_path)
        self.log("[OK] Đã tạo backup: {}".format(backup_path))

        wb = open_workbook_keep_vba(self.xlsm_path)
        clear_old_result_sheets(wb)

        struct_index = build_struct_index(self.source_root, exclude_dirs=self.exclude_dirs, log=self.log)

        results: List[StructResult] = []

        def process(struct_name: str, lineage: Tuple[str, ...] = (), expand: bool = True) -> None:
            no     = len(results) + 1
            level  = len(lineage) + 1
            indent = "  " * len(lineage)

            if struct_name in self.extracted_set:
                self.log("{}[TRÙNG] No{} | Level {}: '{}' → '-'.".format(indent, no, level, struct_name))
                result = StructResult(no=no, struct_name=struct_name, status="Trùng lặp", level=level, file_path="-")
                write_struct_list_row(wb, result)
                results.append(result)
                self.on_result(result)
                return

            self.log("{}Đang xử lý No{} | Level {}: {}".format(indent, no, level, struct_name))
            candidates = struct_index.get(struct_name, [])
            candidate  = self._select_candidate(struct_name, candidates)
            self.extracted_set.add(struct_name)

            if candidate is None:
                result = StructResult(no=no, struct_name=struct_name, status="Không tìm thấy / Bỏ qua", level=level, file_path="-")
                write_struct_list_row(wb, result)
                results.append(result)
                self.on_result(result)
                self.log("{}[CẢNH BÁO] Bỏ qua struct: {}".format(indent, struct_name))
                return

            parsed     = parse_candidate(candidate)
            sheet_name = write_struct_sheet(wb, no, parsed)
            result     = StructResult(
                no=no, struct_name=struct_name, status="Đã trích xuất",
                level=level, file_path=str(candidate.file_path),
                has_compile_switch=parsed.has_compile_switch, sheet_name=sheet_name,
            )
            write_struct_list_row(wb, result)
            results.append(result)
            self.on_result(result)

            if parsed.has_compile_switch:
                self.log("{}[LƯU Ý] {} có #if/#else/#endif → đánh dấu '*'.".format(indent, struct_name))

            if not expand:
                return

            next_lineage = lineage + (struct_name,)
            for sub in parsed.sub_struct_names:
                if sub in next_lineage:
                    self.log("{}[CẢNH BÁO] Vòng lặp: {} → ghi nhưng không mở rộng.".format(
                        indent, " -> ".join(next_lineage + (sub,))))
                    process(sub, next_lineage, expand=False)
                else:
                    process(sub, next_lineage, expand=True)

        for root_name in self.initial_structs:
            process(root_name)

        save_cache(self.cache_path, self.cache)
        save_workbook(wb, self.xlsm_path)
        self.log("[HOÀN TẤT] Đã ghi trực tiếp vào: {}".format(self.xlsm_path))

        csv_rows = self._generate_csv_data()
        csv_path = self._write_csv_report(csv_rows)
        self.log("[OK] Đã xuất báo cáo CSV: {}".format(csv_path))
        return results

    def _generate_csv_data(self) -> List[Dict]:
        csv_rows: List[Dict] = []

        def collect(struct_name: str, lineage: Tuple[str, ...]) -> None:
            no    = len(csv_rows) + 1
            level = len(lineage) + 1
            if struct_name in self.session_chosen:
                cand   = self.session_chosen[struct_name]
                parsed = parse_candidate(cand)
                csv_rows.append({"no": no, "struct_name": struct_name,
                                 "file_path": str(cand.file_path),
                                 "has_compile_switch": parsed.has_compile_switch, "level": level})
                nl = lineage + (struct_name,)
                for sub in parsed.sub_struct_names:
                    if sub not in nl:
                        collect(sub, nl)
            else:
                csv_rows.append({"no": no, "struct_name": struct_name,
                                 "file_path": "-", "has_compile_switch": False, "level": level})

        for root_name in self.initial_structs:
            collect(root_name, ())
        return csv_rows

    def _write_csv_report(self, csv_rows: List[Dict]) -> Path:
        import csv as _csv
        stamp    = datetime.now().strftime("%Y%m%d_%H%M%S")
        csv_path = self.xlsm_path.with_name("struct_report_{}.csv".format(stamp))
        with open(str(csv_path), "w", newline="", encoding="utf-8-sig") as f:
            w = _csv.writer(f)
            w.writerow(["No", "Struct", "Path", "#if", "Level"])
            for row in csv_rows:
                w.writerow([row["no"], row["struct_name"], row["file_path"],
                             "*" if row["has_compile_switch"] else "", row["level"]])
        return csv_path


# ---------------------------------------------------------------------------
# Struct Candidate Dialog
# ---------------------------------------------------------------------------

class StructCandidateDialog:
    """Dialog chọn file khi struct xuất hiện ở nhiều nơi."""

    def __init__(
        self,
        parent: tk.Tk,
        struct_name: str,
        candidates: List[StructCandidate],
        cached_path: Optional[str],
    ) -> None:
        self.candidates  = candidates
        self.cached_path = cached_path
        self.selected: Optional[StructCandidate] = None

        self.win = tk.Toplevel(parent)
        self.win.title("Chọn file chứa struct: {}".format(struct_name))
        self.win.geometry("1100x620")
        self.win.minsize(900, 500)
        self.win.transient(parent)
        self.win.grab_set()
        self.win.protocol("WM_DELETE_WINDOW", self._skip)

        self._build_ui(struct_name)
        self._fill_rows()
        self.win.wait_window()

    def _build_ui(self, struct_name: str) -> None:
        top = ttk.Frame(self.win, padding=10)
        top.pack(fill="both", expand=True)

        ttk.Label(
            top,
            text="Struct '{}' xuất hiện trong {} file.  Dòng màu cam = path đã có trong cache.".format(
                struct_name, len(self.candidates)),
            font=FONT_BOLD, wraplength=1060,
        ).pack(anchor="w", pady=(0, 8))

        cols = ("cache", "file", "start", "end", "comment")
        self.tree = ttk.Treeview(top, columns=cols, show="headings", height=10)
        for col, text, w, anchor in [
            ("cache",   "Cache",           70,  "center"),
            ("file",    "File",            640, "w"),
            ("start",   "Dòng bắt đầu",   100, "center"),
            ("end",     "Dòng kết thúc",  100, "center"),
            ("comment", "Comment",         170, "w"),
        ]:
            self.tree.heading(col, text=text)
            self.tree.column(col, width=w, anchor=anchor)
        self.tree.tag_configure("cached", background=PALETTE["row_cache"])
        self.tree.bind("<<TreeviewSelect>>", self._on_select)

        vsb = ttk.Scrollbar(top, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=vsb.set)
        self.tree.pack(side="top", fill="x")
        vsb.place(in_=self.tree, relx=1.0, rely=0, relheight=1.0, anchor="ne")

        ttk.Label(top, text="Preview struct:", font=FONT_BOLD).pack(anchor="w", pady=(10, 3))
        self.preview = tk.Text(top, height=12, wrap="none", font=FONT_MONO,
                               bg=PALETTE["surface"], fg=PALETTE["text"], relief="flat")
        self.preview.pack(fill="both", expand=True)

        btns = ttk.Frame(top)
        btns.pack(fill="x", pady=(10, 0))
        ttk.Button(btns, text="Chọn file này",    command=self._choose, style="Accent.TButton").pack(side="right", padx=4)
        ttk.Button(btns, text="Bỏ qua struct này", command=self._skip).pack(side="right", padx=4)
        ttk.Button(btns, text="Mở file",           command=self._open_file).pack(side="right", padx=4)

    def _fill_rows(self) -> None:
        first_cached = None
        for idx, cand in enumerate(self.candidates):
            is_cached = bool(
                self.cached_path
                and os.path.normcase(str(cand.file_path)) == os.path.normcase(str(self.cached_path))
            )
            iid = str(idx)
            self.tree.insert("", "end", iid=iid,
                values=("✔" if is_cached else "", str(cand.file_path),
                        cand.start_line, cand.end_line, cand.comment),
                tags=("cached",) if is_cached else (),
            )
            if is_cached and first_cached is None:
                first_cached = iid
        sel = first_cached or ("0" if self.candidates else None)
        if sel:
            self.tree.selection_set(sel)
            self.tree.focus(sel)
            self.tree.see(sel)
        self._on_select()

    def _current(self) -> Optional[StructCandidate]:
        sel = self.tree.selection()
        if not sel:
            return None
        try:
            return self.candidates[int(sel[0])]
        except (ValueError, IndexError):
            return None

    def _on_select(self, _event=None) -> None:
        cand = self._current()
        self.preview.delete("1.0", "end")
        if cand:
            self.preview.insert("1.0", cand.raw_block)

    def _open_file(self) -> None:
        cand = self._current()
        if cand:
            open_path_in_os(cand.file_path)

    def _choose(self) -> None:
        cand = self._current()
        if cand is None:
            messagebox.showwarning("Chưa chọn", "Bạn chưa chọn file nào.", parent=self.win)
            return
        self.selected = cand
        self.win.destroy()

    def _skip(self) -> None:
        self.selected = None
        self.win.destroy()


# ---------------------------------------------------------------------------
# StructTab – GUI tab nhúng vào IntegratedApp
# ---------------------------------------------------------------------------

class StructTab(ttk.Frame):
    """Tab Bước 1: Trích xuất struct, nhúng vào ttk.Notebook."""

    def __init__(
        self,
        parent,
        root_window: tk.Tk,
        xlsm_path_var: tk.StringVar,
        source_path_var: tk.StringVar,
        log_func: Callable[[str], None],
        set_status_func: Callable[[str], None],
        on_done: Optional[Callable[[bool], None]] = None,
        **kwargs,
    ) -> None:
        super().__init__(parent, **kwargs)
        self.root_window     = root_window
        self.xlsm_path_var   = xlsm_path_var
        self.source_path_var = source_path_var
        self.log_func        = log_func
        self.set_status_func = set_status_func
        self.on_done         = on_done

        self.block_var        = tk.StringVar(value="CMN1")
        self.exclude_dirs_var = tk.StringVar()
        self.use_cache_var    = tk.BooleanVar(value=True)
        self.struct_count_var = tk.StringVar(value="Chưa đọc danh sách struct")

        self.loaded_structs: List[str] = []
        self.log_queue: "queue.Queue[str]"    = queue.Queue()
        self.result_queue: "queue.Queue[StructResult]" = queue.Queue()
        self.worker_thread: Optional[threading.Thread] = None
        self._running = False
        self._cache_path = script_dir() / STRUCT_CACHE_FILE

        self._build_ui()
        self._poll_queues()

    # ---- public API --------------------------------------------------------

    def is_running(self) -> bool:
        return self._running

    def start_run(self, skip_confirm: bool = False) -> None:
        self._start_run(skip_confirm=skip_confirm)

    # ---- UI build ----------------------------------------------------------

    def _build_ui(self) -> None:
        ctrl = ttk.Frame(self, padding=(4, 4, 4, 2))
        ctrl.pack(fill="x")

        # Row 0 – Block + use_cache
        r0 = ttk.Frame(ctrl)
        r0.pack(fill="x", pady=(0, 4))
        ttk.Label(r0, text="Input / Block:").pack(side="left")
        ttk.Combobox(r0, textvariable=self.block_var, values=list(BLOCK_COLUMNS.keys()),
                     state="readonly", width=12, font=FONT_UI).pack(side="left", padx=6)
        ttk.Label(r0, textvariable=self.struct_count_var,
                  foreground=PALETTE["muted"], font=FONT_UI).pack(side="left", padx=8)
        ttk.Checkbutton(r0, text="Tự chọn từ cache (không hỏi)",
                        variable=self.use_cache_var).pack(side="right")

        # Row 1 – Exclude dirs
        r1 = ttk.Frame(ctrl)
        r1.pack(fill="x", pady=(0, 4))
        ttk.Label(r1, text="Loại trừ thư mục (;):").pack(side="left")
        ttk.Entry(r1, textvariable=self.exclude_dirs_var,
                  font=FONT_MONO).pack(side="left", fill="x", expand=True, padx=6)
        ttk.Button(r1, text="Thêm...", command=self._add_exclude_dir).pack(side="left")

        # Row 2 – Action buttons + progress
        r2 = ttk.Frame(ctrl)
        r2.pack(fill="x", pady=(0, 4))
        ttk.Button(r2, text="Đọc danh sách struct",
                   command=self._load_structs).pack(side="left")
        self.run_btn = ttk.Button(r2, text="▶  Bắt đầu trích xuất",
                                  command=self._start_run, style="Accent.TButton")
        self.run_btn.pack(side="left", padx=6)
        ttk.Button(r2, text="Xóa kết quả",
                   command=self._clear_results).pack(side="left")
        self.progress = ttk.Progressbar(r2, mode="indeterminate", length=180)
        self.progress.pack(side="right", padx=6)

        # Separator
        ttk.Separator(self, orient="horizontal").pack(fill="x", pady=2)

        # Result treeview
        tree_frame = ttk.Frame(self)
        tree_frame.pack(fill="both", expand=True)
        tree_frame.rowconfigure(0, weight=1)
        tree_frame.columnconfigure(0, weight=1)

        cols = ("no", "level", "struct", "status", "file", "ifdef")
        self.result_tree = ttk.Treeview(tree_frame, columns=cols, show="headings")
        for col, text, w, anchor in [
            ("no",     "No",         55,  "center"),
            ("level",  "Level",      60,  "center"),
            ("struct", "Struct",     220, "w"),
            ("status", "Trạng thái", 140, "w"),
            ("file",   "File đã chọn", 560, "w"),
            ("ifdef",  "#if",        50,  "center"),
        ]:
            self.result_tree.heading(col, text=text)
            self.result_tree.column(col, width=w, anchor=anchor)
        self.result_tree.tag_configure("ok",    background=PALETTE["row_ok"])
        self.result_tree.tag_configure("warn",  background=PALETTE["row_warn"])
        self.result_tree.tag_configure("error", background=PALETTE["row_err"])

        vsb = ttk.Scrollbar(tree_frame, orient="vertical",   command=self.result_tree.yview)
        hsb = ttk.Scrollbar(tree_frame, orient="horizontal", command=self.result_tree.xview)
        self.result_tree.configure(yscrollcommand=vsb.set, xscrollcommand=hsb.set)
        self.result_tree.grid(row=0, column=0, sticky="nsew")
        vsb.grid(row=0, column=1, sticky="ns")
        hsb.grid(row=1, column=0, sticky="ew")

    # ---- Actions -----------------------------------------------------------

    def _add_exclude_dir(self) -> None:
        path = filedialog.askdirectory(title="Chọn thư mục cần loại trừ", parent=self.root_window)
        if path:
            cur = self.exclude_dirs_var.get().strip()
            self.exclude_dirs_var.set("{};{}".format(cur, path) if cur else path)

    def _load_structs(self) -> None:
        xlsm = Path(self.xlsm_path_var.get().strip())
        block = self.block_var.get().strip()
        if not xlsm.exists():
            messagebox.showerror("Thiếu file", "Vui lòng chọn file .xlsm.", parent=self.root_window)
            return
        try:
            structs, source = read_structs_from_workbook(xlsm, block)
            self.loaded_structs = structs
            self.struct_count_var.set("Đã đọc {} struct từ cột {}3↓".format(
                len(structs), BLOCK_COLUMNS[block]))
            self.log_func("[OK] Đã đọc {} struct từ sheet 設定, block {}.".format(len(structs), block))
            if source and not self.source_path_var.get().strip():
                self.source_path_var.set(source)
            self._show_pending_structs()
        except Exception as exc:
            messagebox.showerror("Lỗi đọc Excel", str(exc), parent=self.root_window)
            self.log_func("[ERROR] {}".format(exc))

    def _show_pending_structs(self) -> None:
        self.result_tree.delete(*self.result_tree.get_children())
        for idx, name in enumerate(self.loaded_structs, 1):
            self.result_tree.insert("", "end", values=(idx, "", name, "Chờ xử lý", "", ""))

    def _clear_results(self) -> None:
        self.result_tree.delete(*self.result_tree.get_children())
        self.loaded_structs = []
        self.struct_count_var.set("Chưa đọc danh sách struct")

    def _start_run(self, skip_confirm: bool = False) -> None:
        if self._running:
            return

        xlsm   = Path(self.xlsm_path_var.get().strip())
        source = Path(self.source_path_var.get().strip())

        if not xlsm.exists():
            messagebox.showerror("Thiếu file", "Vui lòng chọn file .xlsm.", parent=self.root_window)
            return
        if not source.exists() or not source.is_dir():
            messagebox.showerror("Thiếu source", "Vui lòng chọn thư mục source .h.", parent=self.root_window)
            return
        if not self.loaded_structs:
            self._load_structs()
            if not self.loaded_structs:
                return

        if not skip_confirm:
            ok = messagebox.askyesno(
                "Xác nhận ghi Excel",
                "Tool sẽ tạo backup, sau đó ghi đè trực tiếp vào file .xlsm gốc.\n\nBạn muốn tiếp tục?",
                parent=self.root_window,
            )
            if not ok:
                return

        self.result_tree.delete(*self.result_tree.get_children())
        self.run_btn.configure(state="disabled")
        self.progress.start(10)
        self._running = True
        self.log_func("=" * 60)
        self.log_func("[INFO] ═══ BẮT ĐẦU BƯỚC 1: TRÍCH XUẤT STRUCT ═══")
        self.set_status_func("Bước 1: Đang trích xuất struct...")

        excl_raw  = self.exclude_dirs_var.get().strip()
        excl_dirs = [Path(p.strip()) for p in excl_raw.split(";") if p.strip()] if excl_raw else []

        engine = StructExtractionEngine(
            xlsm_path=xlsm, source_root=source,
            initial_structs=self.loaded_structs,
            cache_path=self._cache_path,
            choose_candidate=self._choose_candidate_threadsafe,
            exclude_dirs=excl_dirs,
            use_cache=self.use_cache_var.get(),
            log=self._log_ts,
            on_result=self._result_ts,
        )

        def worker() -> None:
            try:
                engine.run()
                self._log_ts("=" * 60)
                self._log_ts("[OK] ═══ BƯỚC 1 HOÀN TẤT ═══")
                self.log_queue.put("__DONE_OK__")
            except Exception as exc:
                self._log_ts("[ERROR] {}".format(exc))
                self.log_queue.put("__DONE_ERROR__{}".format(exc))

        self.worker_thread = threading.Thread(target=worker, daemon=True)
        self.worker_thread.start()

    # ---- Thread-safe helpers -----------------------------------------------

    def _choose_candidate_threadsafe(
        self,
        struct_name: str,
        candidates: List[StructCandidate],
        cached_path: Optional[str],
    ) -> Optional[StructCandidate]:
        holder = {"selected": None}
        event  = threading.Event()

        def show() -> None:
            d = StructCandidateDialog(self.root_window, struct_name, candidates, cached_path)
            holder["selected"] = d.selected
            event.set()

        self.root_window.after(0, show)
        event.wait()
        return holder["selected"]

    def _log_ts(self, msg: str) -> None:
        self.log_queue.put(msg)

    def _result_ts(self, result: StructResult) -> None:
        self.result_queue.put(result)

    # ---- Poll loop ---------------------------------------------------------

    def _poll_queues(self) -> None:
        try:
            while True:
                msg = self.log_queue.get_nowait()
                if msg == "__DONE_OK__":
                    self._on_worker_done(True, None)
                elif msg.startswith("__DONE_ERROR__"):
                    self._on_worker_done(False, msg[14:])
                elif msg.startswith("[STATUS] "):
                    self.set_status_func(msg[9:])
                else:
                    self.log_func(msg)
        except queue.Empty:
            pass

        try:
            while True:
                result = self.result_queue.get_nowait()
                tag = "error" if result.status in ("Không tìm thấy / Bỏ qua",) else \
                      "warn"  if result.status == "Trùng lặp" else "ok"
                self.result_tree.insert("", "end", values=(
                    result.no, result.level, result.struct_name,
                    result.status, result.file_path,
                    "*" if result.has_compile_switch else "",
                ), tags=(tag,))
        except queue.Empty:
            pass

        self.after(100, self._poll_queues)

    def _on_worker_done(self, success: bool, error: Optional[str]) -> None:
        self._running = False
        self.run_btn.configure(state="normal")
        self.progress.stop()
        if success:
            self.set_status_func("Bước 1 hoàn tất  ✓")
            messagebox.showinfo("Hoàn tất",
                "Đã tạo backup và ghi kết quả struct vào file .xlsm.",
                parent=self.root_window)
        else:
            self.set_status_func("Lỗi Bước 1.")
            messagebox.showerror("Lỗi Bước 1", error or "", parent=self.root_window)
        if self.on_done:
            self.on_done(success)
