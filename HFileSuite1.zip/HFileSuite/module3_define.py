# -*- coding: utf-8 -*-
"""
Module 3 – Triển khai số phần tử mảng từ #define/enum trong file .h.

Logic giữ nguyên từ array_define_expander_gui_module3_v1.py.
GUI được tách thành DefineTab(ttk.Frame) để nhúng vào app tích hợp.
DefineTab chạy worker thread (không block main thread) giống Module 1.
"""
from __future__ import annotations

import ast
import os
import queue
import re
import threading
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, Dict, Iterable, List, Optional, Sequence, Set, Tuple, Union

import tkinter as tk
from tkinter import filedialog, messagebox, ttk

try:
    from openpyxl import load_workbook
    from openpyxl.styles import Alignment, Font
except ImportError:
    raise

from common import (
    DEFAULT_SHEET_NAME, IDENT_RE, LINE_COMMENT_RE, MEMBER_DISABLE_MARK,
    MULTI_COMMENT_RE, NO_SHEET_RE, PALETTE, FONT_UI, FONT_BOLD, FONT_MONO,
    load_cache, make_backup, open_path_in_os, read_text_auto, save_cache, script_dir,
)

# ---------------------------------------------------------------------------
# Module-3 constants
# ---------------------------------------------------------------------------
TOOL_VERSION_M3  = "v1_array_define_expander_2026_05_26"
DEFINE_CACHE_FILE = "define_path_cache.json"

DEFINE_NAME_SHEET = "配列要素数定義展開リスト"

DEFINE_NAME_LINE      = 2
DEFINE_NAME_CLM       = 2   # B
DEFINE_NAME_VALUE_CLM = 3   # C
DEFINE_NAME_PATH_CLM  = 4   # D
DEFINE_NAME_DEFAULT_PATH_CELL = "D20"

STRUCT_MEMBER_START_ROW = 2
STRUCT_MARK_CLM  = 1   # A
STRUCT_MEMBER_CLM = 4  # D

IDENT_TOKEN_RE = re.compile(r"\b[A-Za-z_]\w*\b")
ARRAY_TOKEN_RE = re.compile(r"\[([^\]]+)\]")

CAST_TYPES = [
    "U1","U2","U4","U8","S1","S2","S4","S8",
    "X1","X2","X4","X8",
    "A1","A2","A3","A4","A5","A6","A7","A8","A9",
    "FL","DB",
]
CAST_RE = re.compile(r"\(\s*(?:" + "|".join(map(re.escape, CAST_TYPES)) + r")\s*\)")

C_KEYWORDS_M3 = {
    "sizeof","defined","true","false","NULL",
    "U1","U2","U4","U8","S1","S2","S4","S8",
    "X1","X2","X4","X8",
    "A1","A2","A3","A4","A5","A6","A7","A8","A9",
    "FL","DB",
}

DEFINE_RE = re.compile(r"^\s*#\s*define\s+([A-Za-z_]\w*)(.*)$")


# ---------------------------------------------------------------------------
# Data models
# ---------------------------------------------------------------------------

@dataclass
class DefineCandidate:
    name: str
    value_raw: str
    file_path: Path
    line_no: int
    kind: str = "define"

    @property
    def preview(self) -> str:
        return self.value_raw.strip()


@dataclass
class EnumCandidate:
    name: str
    file_path: Path
    line_no: int
    raw_block: str
    enum_start_line: int
    compile_switch_before: bool = False
    kind: str = "enum"

    @property
    def preview(self) -> str:
        return "compile switch" if self.compile_switch_before else "enum item"


Candidate = Union[DefineCandidate, EnumCandidate]


@dataclass
class ResolveResult:
    name: str
    value: str = ""
    path_or_message: str = ""
    status: str = ""
    kind: str = ""
    unresolved: bool = False


@dataclass
class ScanIndex:
    define_index: Dict[str, List[DefineCandidate]] = field(default_factory=dict)
    enum_index:   Dict[str, List[EnumCandidate]]   = field(default_factory=dict)
    file_count: int = 0


# ---------------------------------------------------------------------------
# Comment / normalization helpers
# ---------------------------------------------------------------------------

def remove_comments(text: str) -> str:
    text = MULTI_COMMENT_RE.sub("", text)
    return "\n".join(LINE_COMMENT_RE.sub("", line) for line in text.splitlines())


def remove_comments_one_line(line: str) -> str:
    line = re.sub(r"/\*.*?\*/", "", line)
    return LINE_COMMENT_RE.sub("", line)


def remove_c_casts(expr: str) -> str:
    prev = None
    out  = expr
    while prev != out:
        prev = out
        out  = CAST_RE.sub("", out)
    return out


def normalize_c_integer_literals(expr: str) -> str:
    def repl(m: re.Match) -> str:
        lit = m.group(1)
        try:
            return str(int(lit, 16) if lit.lower().startswith("0x") else int(lit, 10))
        except Exception:
            return lit
    return re.sub(r"\b(0[xX][0-9A-Fa-f]+|\d+)(?:[uUlL]+)?\b", repl, expr)


def normalize_expr(expr: str) -> str:
    expr = remove_comments(expr)
    expr = expr.replace("\\", " ")
    expr = remove_c_casts(expr)
    expr = normalize_c_integer_literals(expr)
    expr = expr.replace("&&", " and ").replace("||", " or ")
    return re.sub(r"\s+", " ", expr).strip()


def compact_expr_for_excel(expr: str) -> str:
    return normalize_expr(expr).replace(" ", "")


def strip_outer_parentheses(expr: str) -> str:
    s = expr.strip()
    changed = True
    while changed and s.startswith("(") and s.endswith(")"):
        changed = False
        depth = 0
        ok    = True
        for idx, ch in enumerate(s):
            if ch == "(":   depth += 1
            elif ch == ")":
                depth -= 1
                if depth == 0 and idx != len(s) - 1:
                    ok = False; break
        if ok:
            s = s[1:-1].strip(); changed = True
    return s


def is_numeric_literal(text: str) -> bool:
    s = strip_outer_parentheses(normalize_expr(text).strip())
    return re.fullmatch(r"[+-]?(?:\d+)", s) is not None


def formula_has_operator(text: str) -> bool:
    s = remove_comments(text)
    return any(op in s for op in ["+", "-", "*", "/", "^", "<<", ">>", "|", "&"])


def is_formula_token(text: str) -> bool:
    return formula_has_operator(text)


def identifiers_in_expr(expr: str) -> List[str]:
    seen: Set[str] = set()
    out: List[str] = []
    for token in IDENT_TOKEN_RE.findall(expr):
        if token not in C_KEYWORDS_M3 and not token.isdigit() and token not in seen:
            seen.add(token)
            out.append(token)
    return out


def is_plain_numeric_expression(expr: str) -> bool:
    s = compact_expr_for_excel(expr)
    return bool(s) and bool(re.fullmatch(r"[0-9+\-*/^(). ]+", s))


def expression_contains_bitwise_or_shift(expr: str) -> bool:
    return any(op in expr for op in ["<<", ">>", "|", "&"])


# ---------------------------------------------------------------------------
# Safe integer evaluator
# ---------------------------------------------------------------------------

class UnsafeExpressionError(Exception):
    pass


def safe_eval_int(expr: str, names: Optional[Dict[str, int]] = None) -> int:
    if names is None:
        names = {}
    expr_norm = normalize_expr(expr)
    tree      = ast.parse(expr_norm, mode="eval")

    allowed_binops = (
        ast.Add, ast.Sub, ast.Mult, ast.Div, ast.FloorDiv, ast.Mod,
        ast.LShift, ast.RShift, ast.BitOr, ast.BitAnd, ast.BitXor,
    )
    allowed_unary = (ast.UAdd, ast.USub, ast.Invert)

    def ev(node: ast.AST) -> int:
        if isinstance(node, ast.Expression):
            return ev(node.body)
        if isinstance(node, ast.Constant):
            if isinstance(node.value, bool):  return int(node.value)
            if isinstance(node.value, (int, float)): return int(node.value)
            raise UnsafeExpressionError("constant không hợp lệ")
        if hasattr(ast, "Num") and isinstance(node, ast.Num):  # py3.9
            return int(node.n)  # type: ignore[attr-defined]
        if isinstance(node, ast.Name):
            if node.id in names: return int(names[node.id])
            raise UnsafeExpressionError("unknown name: {}".format(node.id))
        if isinstance(node, ast.UnaryOp) and isinstance(node.op, allowed_unary):
            val = ev(node.operand)
            if isinstance(node.op, ast.UAdd):   return +val
            if isinstance(node.op, ast.USub):   return -val
            if isinstance(node.op, ast.Invert): return ~val
        if isinstance(node, ast.BinOp) and isinstance(node.op, allowed_binops):
            L, R = ev(node.left), ev(node.right)
            op   = node.op
            if isinstance(op, ast.Add):      return L + R
            if isinstance(op, ast.Sub):      return L - R
            if isinstance(op, ast.Mult):     return L * R
            if isinstance(op, ast.Div):
                if R == 0: raise UnsafeExpressionError("division by zero")
                return int(L / R)
            if isinstance(op, ast.FloorDiv):
                if R == 0: raise UnsafeExpressionError("division by zero")
                return L // R
            if isinstance(op, ast.Mod):
                if R == 0: raise UnsafeExpressionError("mod by zero")
                return L % R
            if isinstance(op, ast.LShift):  return L << R
            if isinstance(op, ast.RShift):  return L >> R
            if isinstance(op, ast.BitOr):   return L | R
            if isinstance(op, ast.BitAnd):  return L & R
            if isinstance(op, ast.BitXor):  return L ^ R
        raise UnsafeExpressionError("node không hợp lệ: {}".format(type(node).__name__))

    return ev(tree)


# ---------------------------------------------------------------------------
# Excel I/O (Module 3)
# ---------------------------------------------------------------------------

def read_default_source_path_from_workbook(xlsm_path: Path) -> str:
    wb = load_workbook(str(xlsm_path), keep_vba=True, data_only=False)
    try:
        if DEFAULT_SHEET_NAME not in wb.sheetnames:
            return ""
        val = wb[DEFAULT_SHEET_NAME][DEFINE_NAME_DEFAULT_PATH_CELL].value
        return str(val).strip() if val is not None else ""
    finally:
        wb.close()


def ensure_define_sheet(wb):
    if DEFINE_NAME_SHEET in wb.sheetnames:
        ws = wb[DEFINE_NAME_SHEET]
    else:
        ws = wb.create_sheet(DEFINE_NAME_SHEET)
    headers = {
        DEFINE_NAME_CLM:       "定義名",
        DEFINE_NAME_VALUE_CLM: "定義値",
        DEFINE_NAME_PATH_CLM:  "検索パス",
    }
    for col, text in headers.items():
        if ws.cell(1, col).value in (None, ""):
            ws.cell(1, col).value = text
        ws.cell(1, col).font      = Font(bold=True)
        ws.cell(1, col).alignment = Alignment(horizontal="center")
    return ws


def clear_define_sheet(ws) -> None:
    max_row = max(ws.max_row, DEFINE_NAME_LINE)
    for row in range(DEFINE_NAME_LINE, max_row + 1):
        for col in range(DEFINE_NAME_CLM, DEFINE_NAME_PATH_CLM + 1):
            ws.cell(row, col).value = None


def no_sheet_sort_key(name: str) -> int:
    m = NO_SHEET_RE.match(name)
    return int(m.group(1)) if m else 999999


def is_member_enabled(ws, row: int) -> bool:
    return ws.cell(row, STRUCT_MARK_CLM).value != MEMBER_DISABLE_MARK


def is_end_of_member_list(ws, row: int) -> bool:
    member = ws.cell(row, STRUCT_MEMBER_CLM).value
    return (member is None or str(member) == "") and is_member_enabled(ws, row)


def extract_array_tokens_from_member(member_name: str) -> List[str]:
    tokens = []
    for raw in ARRAY_TOKEN_RE.findall(member_name):
        token = str(raw).strip()
        if token and not is_numeric_literal(token):
            tokens.append(token)
    return tokens


def read_array_tokens_from_no_sheets(wb) -> List[str]:
    sheet_names = sorted(
        [n for n in wb.sheetnames if NO_SHEET_RE.match(n)],
        key=no_sheet_sort_key,
    )
    tokens: List[str] = []
    seen:   Set[str]  = set()
    for sheet_name in sheet_names:
        ws  = wb[sheet_name]
        row = STRUCT_MEMBER_START_ROW
        lim = max(ws.max_row + 1, STRUCT_MEMBER_START_ROW)
        while row <= lim:
            if is_end_of_member_list(ws, row):
                break
            if is_member_enabled(ws, row):
                member = ws.cell(row, STRUCT_MEMBER_CLM).value
                if member is not None:
                    for t in extract_array_tokens_from_member(str(member)):
                        if t not in seen:
                            seen.add(t); tokens.append(t)
            row += 1
    return tokens


def _to_number(s: str):
    """Convert numeric string to int/float for Excel; keep formulas and non-numeric as-is."""
    if not isinstance(s, str) or not s or s.startswith("="):
        return s
    try:
        return int(s, 0)
    except (ValueError, TypeError):
        pass
    try:
        return float(s)
    except (ValueError, TypeError):
        return s


def write_define_results(ws, results: List[ResolveResult]) -> None:
    clear_define_sheet(ws)
    row = DEFINE_NAME_LINE
    for r in results:
        ws.cell(row, DEFINE_NAME_CLM).value       = r.name
        ws.cell(row, DEFINE_NAME_VALUE_CLM).value = _to_number(r.value)
        ws.cell(row, DEFINE_NAME_PATH_CLM).value  = r.path_or_message
        row += 1
    for col_letter in ["B", "C", "D"]:
        max_len = 10
        for cell in ws[col_letter]:
            if cell.value is not None:
                max_len = max(max_len, min(len(str(cell.value)) + 2, 120))
        ws.column_dimensions[col_letter].width = max_len


# ---------------------------------------------------------------------------
# Source scanner
# ---------------------------------------------------------------------------

def iter_h_files(source_root: Path) -> Iterable[Path]:
    for path in source_root.rglob("*.h"):
        if path.is_file():
            yield path


def join_define_multiline(lines: Sequence[str], start: int) -> Tuple[str, int]:
    parts = []
    idx   = start
    while idx < len(lines):
        line = lines[idx].rstrip("\r\n")
        if line.rstrip().endswith("\\"):
            parts.append(line.rstrip()[:-1]); idx += 1; continue
        parts.append(line); break
    return " ".join(parts), idx


def scan_defines_in_file(path: Path) -> List[DefineCandidate]:
    text, _ = read_text_auto(path)
    lines   = text.splitlines()
    out: List[DefineCandidate] = []
    i = 0
    while i < len(lines):
        if re.match(r"^\s*#\s*define\b", lines[i]):
            joined, end_idx = join_define_multiline(lines, i)
            m = DEFINE_RE.match(joined)
            if m:
                rest = m.group(2)
                if not rest.startswith("("):
                    value_raw = remove_comments(rest.strip()).strip()
                    out.append(DefineCandidate(name=m.group(1), value_raw=value_raw,
                                              file_path=path, line_no=i + 1))
            i = end_idx + 1; continue
        i += 1
    return out


def collect_enum_blocks(path: Path) -> List[Tuple[str, int]]:
    text, _  = read_text_auto(path)
    lines    = text.splitlines()
    blocks: List[Tuple[str, int]] = []
    i = 0
    while i < len(lines):
        line = remove_comments_one_line(lines[i])
        if re.search(r"\benum\b", line):
            start = i; block_lines: List[str] = []
            brace_count = 0; started = False
            j = i
            while j < len(lines):
                cur   = lines[j]; block_lines.append(cur)
                clean = remove_comments_one_line(cur)
                if "{" in clean: started = True
                if started:
                    brace_count += clean.count("{")
                    brace_count -= clean.count("}")
                    if brace_count <= 0 and "}" in clean:
                        blocks.append(("\n".join(block_lines), start + 1)); i = j; break
                j += 1
        i += 1
    return blocks


def enum_body_lines(raw_block: str, start_line: int) -> List[Tuple[str, int]]:
    lines  = raw_block.splitlines()
    output: List[Tuple[str, int]] = []
    in_body = False
    for idx, line in enumerate(lines):
        line_no = start_line + idx
        working = line
        if not in_body:
            if "{" not in working: continue
            working = working.split("{", 1)[1]; in_body = True
        if "}" in working:
            working = working.split("}", 1)[0]
            if working.strip(): output.append((working, line_no))
            break
        output.append((working, line_no))
    return output


def parse_enum_items(raw_block: str, start_line: int) -> List[Tuple[str, Optional[str], int, bool]]:
    items: List[Tuple[str, Optional[str], int, bool]] = []
    switch_seen = False
    for line, line_no in enum_body_lines(raw_block, start_line):
        stripped = line.strip()
        if stripped.startswith(("#if", "#ifdef", "#ifndef", "#elif", "#else", "#endif")):
            switch_seen = True; continue
        clean = remove_comments_one_line(line)
        if not clean.strip(): continue
        for part in clean.split(","):
            part = part.strip()
            if not part: continue
            if "{" in part: part = part.split("{", 1)[1].strip()
            if not part or part.startswith("#"): continue
            m = re.match(r"^([A-Za-z_]\w*)\s*(?:=\s*(.+))?$", part)
            if not m: continue
            expr = m.group(2).strip() if m.group(2) is not None else None
            items.append((m.group(1), expr, line_no, switch_seen))
    return items


def scan_enums_in_file(path: Path) -> List[EnumCandidate]:
    out: List[EnumCandidate] = []
    for raw_block, start_line in collect_enum_blocks(path):
        for name, _expr, line_no, sw in parse_enum_items(raw_block, start_line):
            out.append(EnumCandidate(
                name=name, file_path=path, line_no=line_no,
                raw_block=raw_block, enum_start_line=start_line,
                compile_switch_before=sw,
            ))
    return out


def scan_source_headers(
    source_root: Path,
    log: Optional[Callable[[str], None]] = None,
) -> ScanIndex:
    index = ScanIndex()
    files = list(iter_h_files(source_root))
    index.file_count = len(files)
    if log: log("[INFO] Đang scan {} file .h...".format(len(files)))

    for idx, path in enumerate(files, 1):
        try:
            for cand in scan_defines_in_file(path):
                index.define_index.setdefault(cand.name, []).append(cand)
            for cand in scan_enums_in_file(path):
                index.enum_index.setdefault(cand.name, []).append(cand)
        except Exception as exc:
            if log: log("[WARN] Không đọc được {}: {}".format(path, exc))
        if log and idx % 200 == 0:
            log("[INFO] Đã scan {}/{} file .h".format(idx, len(files)))

    if log:
        log("[OK] Scan xong: {} define, {} enum item.".format(
            len(index.define_index), len(index.enum_index)))
    return index


# ---------------------------------------------------------------------------
# Resolver
# ---------------------------------------------------------------------------

class DefineResolver:
    def __init__(
        self,
        scan_index: ScanIndex,
        cache: Dict[str, str],
        choose_candidate: Callable[[str, List[Candidate]], Optional[Candidate]],
        log: Optional[Callable[[str], None]] = None,
    ):
        self.index           = scan_index
        self.cache           = cache
        self.choose_candidate = choose_candidate
        self.log             = log or (lambda _: None)
        self.memo:      Dict[str, ResolveResult] = {}
        self.resolving: Set[str]                 = set()

    def resolve_token(self, token: str) -> ResolveResult:
        token = token.strip()
        if not token:
            return ResolveResult(name=token, value="", path_or_message="Token rỗng",
                                 status="Lỗi", unresolved=True)

        if is_formula_token(token) and not IDENT_RE.match(token):
            v, p, s, u = self.resolve_expression(token)
            return ResolveResult(name=token, value=v, path_or_message=p,
                                 status=s, kind="formula", unresolved=u)

        if IDENT_RE.match(token):
            return self.resolve_name(token)

        stripped = strip_outer_parentheses(token)
        if IDENT_RE.match(stripped):
            return self.resolve_name(stripped)

        v, p, s, u = self.resolve_expression(token)
        return ResolveResult(name=token, value=v, path_or_message=p,
                             status=s, kind="formula", unresolved=u)

    def resolve_name(self, name: str) -> ResolveResult:
        if name in self.memo:
            return self.memo[name]
        if name in self.resolving:
            return ResolveResult(name=name, value="", path_or_message="Vòng lặp define",
                                 status="Lỗi", unresolved=True)
        self.resolving.add(name)
        try:
            define_cands = self.index.define_index.get(name, [])
            if define_cands:
                cand = self._pick(name, define_cands)
                result = (
                    ResolveResult(name=name, value="", path_or_message="Người dùng bỏ qua",
                                  status="Bỏ qua", kind="define", unresolved=True)
                    if cand is None
                    else self._resolve_define(cand)  # type: ignore[arg-type]
                )
                self.memo[name] = result; return result

            enum_cands = self.index.enum_index.get(name, [])
            if enum_cands:
                cand2 = self._pick(name, enum_cands)
                result2 = (
                    ResolveResult(name=name, value="", path_or_message="Người dùng bỏ qua",
                                  status="Bỏ qua", kind="enum", unresolved=True)
                    if cand2 is None
                    else self._resolve_enum(cand2)  # type: ignore[arg-type]
                )
                self.memo[name] = result2; return result2

            result3 = ResolveResult(name=name, value="",
                                    path_or_message="検出できませんでした。",
                                    status="Không tìm thấy", unresolved=True)
            self.memo[name] = result3; return result3
        finally:
            self.resolving.discard(name)

    def _pick(self, name: str, candidates: List[Candidate]) -> Optional[Candidate]:
        if len(candidates) == 1:
            return candidates[0]
        self.log("[CẦN CHỌN] {} xuất hiện trong {} file.".format(name, len(candidates)))
        chosen = self.choose_candidate(name, candidates)
        if chosen is not None:
            self.cache[name] = str(chosen.file_path)
        return chosen

    def _resolve_define(self, cand: DefineCandidate) -> ResolveResult:
        raw = cand.value_raw.strip()
        if not raw:
            return ResolveResult(cand.name, "", str(cand.file_path), "Define rỗng", "define", True)
        norm = strip_outer_parentheses(normalize_expr(raw))
        if is_numeric_literal(norm):
            return ResolveResult(cand.name, str(safe_eval_int(norm)), str(cand.file_path), "OK", "define", False)
        v, _, s, u = self.resolve_expression(norm)
        return ResolveResult(cand.name, v, str(cand.file_path), s, "define", u)

    def resolve_expression(self, expr: str) -> Tuple[str, str, str, bool]:
        norm = strip_outer_parentheses(normalize_expr(expr))
        if is_numeric_literal(norm):
            try:    return str(safe_eval_int(norm)), "", "OK", False
            except: return compact_expr_for_excel(norm), "", "Không tính được", True

        names    = identifiers_in_expr(norm)
        replaced = norm
        unresolved: List[str] = []

        for name in names:
            res = self.resolve_name(name)
            if res.unresolved or res.value == "":
                unresolved.append(name); continue
            repl = res.value
            if repl.startswith("="): repl = "({})".format(repl[1:])
            repl     = strip_outer_parentheses(str(repl))
            replaced = re.sub(r"\b{}\b".format(re.escape(name)), repl, replaced)

        replaced = normalize_expr(replaced)
        compact  = compact_expr_for_excel(replaced)

        if unresolved:
            return compact, "Chưa resolve: {}".format(", ".join(unresolved)), "Chưa đủ", True

        if expression_contains_bitwise_or_shift(compact):
            try:    return str(safe_eval_int(compact)), "", "OK", False
            except: return compact, "Không tính được expression", "Không tính được", True

        if is_plain_numeric_expression(compact):
            try:
                if is_numeric_literal(compact):
                    return str(safe_eval_int(compact)), "", "OK", False
                return "=" + compact, "", "OK", False
            except:
                return "=" + compact, "", "OK", False

        return compact, "Expression không hỗ trợ", "Không tính được", True

    def _resolve_enum(self, cand: EnumCandidate) -> ResolveResult:
        if cand.compile_switch_before:
            return ResolveResult(cand.name, "",
                                 "コンパイルスイッチのためか検出できませんでした。(enum定義)",
                                 "Compile switch", "enum", True)

        enum_values: Dict[str, int] = {}
        current = -1
        target_value: Optional[int] = None
        target_found = False

        for name, expr, _lno, sw in parse_enum_items(cand.raw_block, cand.enum_start_line):
            if sw and name == cand.name:
                return ResolveResult(cand.name, "",
                                     "コンパイルスイッチのためか検出できませんでした。(enum定義)",
                                     "Compile switch", "enum", True)
            if expr is None or expr == "":
                current += 1
            else:
                try:
                    current = self._eval_enum_expr(expr, enum_values)
                except Exception:
                    if name == cand.name:
                        return ResolveResult(cand.name, "",
                                             "Không tính được enum initializer: {}".format(expr),
                                             "Không tính được", "enum", True)
                    current = 0
            enum_values[name] = current
            if name == cand.name:
                target_value = current; target_found = True; break

        if target_found and target_value is not None:
            return ResolveResult(cand.name, str(target_value), str(cand.file_path), "OK", "enum", False)
        return ResolveResult(cand.name, "", "Enum item không tìm thấy trong block", "Lỗi", "enum", True)

    def _eval_enum_expr(self, expr: str, enum_values: Dict[str, int]) -> int:
        norm  = strip_outer_parentheses(normalize_expr(expr))
        names = identifiers_in_expr(norm)
        env: Dict[str, int] = dict(enum_values)
        for name in names:
            if name in env: continue
            res = self.resolve_name(name)
            if res.unresolved or res.value == "":
                raise UnsafeExpressionError("Không resolve được {}".format(name))
            val_text = str(res.value)
            if val_text.startswith("="): val_text = val_text[1:]
            env[name] = safe_eval_int(val_text)
        return safe_eval_int(norm, env)


# ---------------------------------------------------------------------------
# Define Candidate Dialog
# ---------------------------------------------------------------------------

class DefineCandidateDialog(tk.Toplevel):
    """Dialog chọn file khi define/enum xuất hiện ở nhiều nơi."""

    def __init__(
        self,
        parent: tk.Tk,
        name: str,
        candidates: List[Candidate],
        cache: Dict[str, str],
    ):
        super().__init__(parent)
        self.title("Chọn file định nghĩa cho {}".format(name))
        self.geometry("1050x420")
        self.minsize(900, 360)
        self.transient(parent)
        self.grab_set()

        self.name       = name
        self.candidates = candidates
        self.cache      = cache
        self.selected: Optional[Candidate] = None

        self._build_ui()
        self._populate()
        self.protocol("WM_DELETE_WINDOW", self._on_skip)

    def _build_ui(self) -> None:
        ttk.Label(
            self,
            text="{} xuất hiện ở nhiều file. Chọn đúng file để tiếp tục.  Dòng màu cam = path đã có trong cache.".format(self.name),
            font=FONT_BOLD, wraplength=1030,
        ).pack(fill="x", padx=10, pady=(10, 6))

        cols = ("cache", "kind", "name", "preview", "line", "file")
        self.tree = ttk.Treeview(self, columns=cols, show="headings", height=12)
        for col, text, w, anchor in [
            ("cache",   "Cache",   70,  "center"),
            ("kind",    "Loại",    80,  "center"),
            ("name",    "Tên",     200, "w"),
            ("preview", "Preview", 220, "w"),
            ("line",    "Dòng",    70,  "center"),
            ("file",    "File",    520, "w"),
        ]:
            self.tree.heading(col, text=text)
            self.tree.column(col, width=w, anchor=anchor)
        self.tree.tag_configure("cached", background=PALETTE["row_cache"])

        vsb = ttk.Scrollbar(self, orient="vertical",   command=self.tree.yview)
        xsb = ttk.Scrollbar(self, orient="horizontal", command=self.tree.xview)
        self.tree.configure(yscrollcommand=vsb.set, xscrollcommand=xsb.set)
        self.tree.pack(side="top", fill="both", expand=True, padx=10)
        vsb.place(in_=self.tree, relx=1.0, rely=0, relheight=1.0, anchor="ne")
        xsb.pack(fill="x", padx=10)

        btns = ttk.Frame(self)
        btns.pack(fill="x", padx=10, pady=10)
        ttk.Button(btns, text="Chọn file này", command=self._on_choose, style="Accent.TButton").pack(side="right", padx=4)
        ttk.Button(btns, text="Bỏ qua",        command=self._on_skip).pack(side="right", padx=4)
        ttk.Button(btns, text="Mở file",        command=self._on_open).pack(side="right", padx=4)

    def _populate(self) -> None:
        cached_path = self.cache.get(self.name, "")
        cached_iid  = None
        for idx, cand in enumerate(self.candidates):
            path_str  = str(cand.file_path)
            is_cached = bool(cached_path and
                os.path.normcase(os.path.abspath(cached_path)) ==
                os.path.normcase(os.path.abspath(path_str)))
            iid = str(idx)
            self.tree.insert("", "end", iid=iid,
                values=("✔" if is_cached else "", cand.kind, cand.name,
                        cand.preview, cand.line_no, path_str),
                tags=("cached",) if is_cached else (),
            )
            if is_cached: cached_iid = iid
        sel = cached_iid or ("0" if self.candidates else None)
        if sel:
            self.tree.selection_set(sel)
            self.tree.see(sel)

    def _selected_idx(self) -> Optional[int]:
        sel = self.tree.selection()
        if not sel: return None
        try:    return int(sel[0])
        except: return None

    def _on_choose(self) -> None:
        idx = self._selected_idx()
        if idx is None:
            messagebox.showwarning("Chưa chọn", "Vui lòng chọn một dòng.", parent=self)
            return
        self.selected = self.candidates[idx]
        self.destroy()

    def _on_open(self) -> None:
        idx = self._selected_idx()
        if idx is not None: open_path_in_os(self.candidates[idx].file_path)

    def _on_skip(self) -> None:
        self.selected = None
        self.destroy()


# ---------------------------------------------------------------------------
# DefineTab – GUI tab nhúng vào IntegratedApp
# ---------------------------------------------------------------------------

class DefineTab(ttk.Frame):
    """Tab Bước 2: Triển khai define/enum, nhúng vào ttk.Notebook."""

    def __init__(
        self,
        parent,
        root_window: tk.Tk,
        xlsm_path_var: tk.StringVar,
        source_path_var: tk.StringVar,
        log_func: Callable[[str], None],
        set_status_func: Callable[[str], None],
        on_done: Optional[Callable[[bool], None]] = None,
        **kwargs,
    ) -> None:
        super().__init__(parent, **kwargs)
        self.root_window     = root_window
        self.xlsm_path_var   = xlsm_path_var
        self.source_path_var = source_path_var
        self.log_func        = log_func
        self.set_status_func = set_status_func
        self.on_done         = on_done

        self.token_count_var = tk.StringVar(value="Chưa đọc token")
        self.tokens: List[str] = []

        self.log_queue: "queue.Queue[str]"          = queue.Queue()
        self.result_queue: "queue.Queue[ResolveResult]" = queue.Queue()
        self.worker_thread: Optional[threading.Thread]   = None
        self._running    = False
        self._cancel_event = threading.Event()
        self._define_cache: Dict[str, str] = {}
        self._cache_path = script_dir() / DEFINE_CACHE_FILE

        self._build_ui()
        self._poll_queues()

    # ---- public API --------------------------------------------------------

    def is_running(self) -> bool:
        return self._running

    def start_run(self) -> None:
        self._start_expand()

    # ---- UI build ----------------------------------------------------------

    def _build_ui(self) -> None:
        ctrl = ttk.Frame(self, padding=(4, 4, 4, 2))
        ctrl.pack(fill="x")

        # Buttons + token count + progress
        r0 = ttk.Frame(ctrl)
        r0.pack(fill="x", pady=(0, 4))
        ttk.Button(r0, text="Đọc token từ sheet No*",
                   command=self._read_tokens_action).pack(side="left")
        ttk.Button(r0, text="Quét define/enum trong .h",
                   command=self._scan_source_action).pack(side="left", padx=6)
        self.run_btn = ttk.Button(r0, text="▶  Bắt đầu triển khai",
                                  command=self._start_expand, style="Accent.TButton")
        self.run_btn.pack(side="left", padx=6)
        self.cancel_btn = ttk.Button(r0, text="■ Hủy", command=self._cancel_expand, state="disabled")
        self.cancel_btn.pack(side="left", padx=(0, 6))
        ttk.Button(r0, text="Mở cache define",
                   command=lambda: open_path_in_os(self._cache_path)).pack(side="left", padx=6)
        ttk.Label(r0, textvariable=self.token_count_var,
                  foreground=PALETTE["muted"], font=FONT_UI).pack(side="left", padx=10)
        self.progress = ttk.Progressbar(r0, mode="indeterminate", length=180)
        self.progress.pack(side="right", padx=6)

        ttk.Separator(self, orient="horizontal").pack(fill="x", pady=2)

        # Result treeview
        tree_frame = ttk.Frame(self)
        tree_frame.pack(fill="both", expand=True)
        tree_frame.rowconfigure(0, weight=1)
        tree_frame.columnconfigure(0, weight=1)

        cols = ("no", "name", "value", "kind", "status", "path")
        self.result_tree = ttk.Treeview(tree_frame, columns=cols, show="headings")
        for col, text, w, anchor in [
            ("no",     "No",           55,  "center"),
            ("name",   "Define/Enum",  240, "w"),
            ("value",  "Giá trị",      160, "w"),
            ("kind",   "Loại",         80,  "center"),
            ("status", "Trạng thái",   120, "w"),
            ("path",   "Path / Message", 520, "w"),
        ]:
            self.result_tree.heading(col, text=text)
            self.result_tree.column(col, width=w, anchor=anchor)
        self.result_tree.tag_configure("ok",    background=PALETTE["row_ok"])
        self.result_tree.tag_configure("warn",  background=PALETTE["row_warn"])
        self.result_tree.tag_configure("error", background=PALETTE["row_err"])

        vsb = ttk.Scrollbar(tree_frame, orient="vertical",   command=self.result_tree.yview)
        hsb = ttk.Scrollbar(tree_frame, orient="horizontal", command=self.result_tree.xview)
        self.result_tree.configure(yscrollcommand=vsb.set, xscrollcommand=hsb.set)
        self.result_tree.grid(row=0, column=0, sticky="nsew")
        vsb.grid(row=0, column=1, sticky="ns")
        hsb.grid(row=1, column=0, sticky="ew")

    # ---- Actions -----------------------------------------------------------

    def _read_tokens_action(self) -> None:
        xlsm = Path(self.xlsm_path_var.get().strip())
        if not xlsm.exists():
            messagebox.showerror("Thiếu file", "Vui lòng chọn file .xlsm.", parent=self.root_window)
            return
        try:
            wb = load_workbook(str(xlsm), keep_vba=True, data_only=False)
            self.tokens = read_array_tokens_from_no_sheets(wb)
            self.token_count_var.set("Đọc được {} token".format(len(self.tokens)))
            self.log_func("[OK] Đọc được {} token từ các sheet No*.".format(len(self.tokens)))
            self.result_tree.delete(*self.result_tree.get_children())
            for idx, t in enumerate(self.tokens, 1):
                self.result_tree.insert("", "end",
                    values=(idx, t, "", "", "Chưa triển khai", ""))
        except Exception as exc:
            messagebox.showerror("Lỗi đọc Excel", str(exc), parent=self.root_window)
            self.log_func("[ERROR] {}".format(exc))

    def _scan_source_action(self) -> None:
        source = Path(self.source_path_var.get().strip())
        if not source.exists() or not source.is_dir():
            messagebox.showerror("Thiếu source", "Vui lòng chọn thư mục source .h.", parent=self.root_window)
            return
        self.set_status_func("Đang scan source...")
        try:
            scan_source_headers(source, self.log_func)
            self.set_status_func("Scan xong.")
        except Exception as exc:
            messagebox.showerror("Lỗi scan", str(exc), parent=self.root_window)
            self.log_func("[ERROR] {}".format(exc))
            self.set_status_func("Lỗi scan.")

    def _start_expand(self) -> None:
        if self._running:
            return

        xlsm   = Path(self.xlsm_path_var.get().strip())
        source = Path(self.source_path_var.get().strip())

        if not xlsm.exists():
            messagebox.showerror("Thiếu file", "Vui lòng chọn file .xlsm.", parent=self.root_window)
            return
        if not source.exists() or not source.is_dir():
            messagebox.showerror("Thiếu source", "Vui lòng chọn thư mục source .h.", parent=self.root_window)
            return

        self.result_tree.delete(*self.result_tree.get_children())
        self._cancel_event.clear()
        self.run_btn.configure(state="disabled")
        self.cancel_btn.configure(state="normal")
        self.progress.start(10)
        self._running = True
        self._define_cache = load_cache(self._cache_path)
        self.log_func("=" * 60)
        self.log_func("[INFO] ═══ BẮT ĐẦU BƯỚC 2: TRIỂN KHAI DEFINE/ENUM ═══")
        self.set_status_func("Bước 2: Đang triển khai define/enum...")

        xlsm_snap   = xlsm
        source_snap = source

        def worker() -> None:
            try:
                backup = make_backup(xlsm_snap)
                self._log_ts("[OK] Đã tạo backup: {}".format(backup))

                wb       = load_workbook(str(xlsm_snap), keep_vba=True, data_only=False)
                ws_def   = ensure_define_sheet(wb)
                tokens   = read_array_tokens_from_no_sheets(wb)
                self._log_ts("[OK] Đọc được {} token từ các sheet No*.".format(len(tokens)))

                if not tokens:
                    self.log_queue.put("__NO_TOKENS__"); return

                self.after(0, lambda: self.token_count_var.set("{} token".format(len(tokens))))
                scan_index = scan_source_headers(source_snap, self._log_ts)

                resolver = DefineResolver(
                    scan_index=scan_index,
                    cache=self._define_cache,
                    choose_candidate=self._choose_candidate_ts,
                    log=self._log_ts,
                )

                results: List[ResolveResult] = []
                total = len(tokens)
                for idx, token in enumerate(tokens, 1):
                    if self._cancel_event.is_set():
                        break
                    self._log_ts("[STATUS] Đang xử lý {}/{}: {}".format(idx, total, token))
                    result = resolver.resolve_token(token)
                    results.append(result)
                    self.result_queue.put(result)
                    if result.unresolved:
                        self._log_ts("[WARN] {} → {} | {}".format(token, result.value, result.path_or_message))
                    else:
                        self._log_ts("[OK] {} → {}".format(token, result.value))

                if self._cancel_event.is_set():
                    self._log_ts("[INFO] Đã hủy — kết quả không được lưu vào Excel.")
                    self.log_queue.put("__DONE_CANCELLED__")
                    return

                write_define_results(ws_def, results)
                wb.save(str(xlsm_snap))
                save_cache(self._cache_path, self._define_cache)
                self._log_ts("=" * 60)
                self._log_ts("[OK] ═══ BƯỚC 2 HOÀN TẤT ═══")
                self.log_queue.put("__DONE_OK__")
            except Exception as exc:
                self._log_ts("[ERROR] {}".format(exc))
                self.log_queue.put("__DONE_ERROR__{}".format(exc))

        self.worker_thread = threading.Thread(target=worker, daemon=True)
        self.worker_thread.start()

    # ---- Thread-safe helpers -----------------------------------------------

    def _choose_candidate_ts(self, name: str, candidates: List[Candidate]) -> Optional[Candidate]:
        holder = {"selected": None}
        event  = threading.Event()

        def show() -> None:
            dialog = DefineCandidateDialog(self.root_window, name, candidates, self._define_cache)
            self.root_window.wait_window(dialog)
            holder["selected"] = dialog.selected
            event.set()

        self.root_window.after(0, show)
        event.wait()
        return holder["selected"]

    def _log_ts(self, msg: str) -> None:
        self.log_queue.put(msg)

    # ---- Poll loop ---------------------------------------------------------

    def _poll_queues(self) -> None:
        try:
            while True:
                msg = self.log_queue.get_nowait()
                if msg == "__DONE_OK__":
                    self._on_worker_done(True, None)
                elif msg == "__DONE_CANCELLED__":
                    self._on_worker_done(None, None)
                elif msg == "__NO_TOKENS__":
                    self._on_worker_done(False, None)
                    messagebox.showinfo("Không có dữ liệu",
                        "Không tìm thấy member array dùng define/enum trong các sheet No*.",
                        parent=self.root_window)
                elif msg.startswith("__DONE_ERROR__"):
                    self._on_worker_done(False, msg[14:])
                elif msg.startswith("[STATUS] "):
                    self.set_status_func(msg[9:])
                else:
                    self.log_func(msg)
        except queue.Empty:
            pass

        try:
            while True:
                result = self.result_queue.get_nowait()
                no  = len(self.result_tree.get_children()) + 1
                tag = ("error" if result.unresolved or result.status in
                       ("Không tìm thấy", "Lỗi", "Không tính được")
                       else "warn" if result.status not in ("OK", "Đã đọc") else "ok")
                self.result_tree.insert("", "end", values=(
                    no, result.name, result.value, result.kind,
                    result.status, result.path_or_message,
                ), tags=(tag,))
        except queue.Empty:
            pass

        self.after(100, self._poll_queues)

    def _cancel_expand(self) -> None:
        self._cancel_event.set()
        self.cancel_btn.configure(state="disabled")
        self.set_status_func("Đang hủy...")

    def _on_worker_done(self, success, error: Optional[str]) -> None:
        self._running = False
        self.run_btn.configure(state="normal")
        self.cancel_btn.configure(state="disabled")
        self.progress.stop()
        if success is None:
            self.set_status_func("Đã hủy.")
        elif success:
            self.set_status_func("Bước 2 hoàn tất  ✓")
            messagebox.showinfo("Hoàn tất",
                "Đã triển khai số phần tử mảng và ghi vào Excel.",
                parent=self.root_window)
        elif error:
            self.set_status_func("Lỗi Bước 2.")
            messagebox.showerror("Lỗi Bước 2", error, parent=self.root_window)
        if self.on_done:
            self.on_done(bool(success))
