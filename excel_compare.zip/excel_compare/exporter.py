import csv
from collections import defaultdict
from typing import List

import openpyxl
from openpyxl.styles import Font, PatternFill

from comparator import DiffResult

_HEADER_FONT = Font(bold=True)
_RED_FILL = PatternFill(start_color="FFCCCC", end_color="FFCCCC", fill_type="solid")
_HEADER_FILL = PatternFill(start_color="D9E1F2", end_color="D9E1F2", fill_type="solid")


def export_csv(diffs: List[DiffResult], output_path: str) -> None:
    with open(output_path, "w", newline="", encoding="utf-8-sig") as f:
        writer = csv.writer(f)
        writer.writerow(["Sheet", "Cell", "File A Value", "File B Value"])
        for d in diffs:
            writer.writerow([d.sheet, d.cell_addr, d.val_a, d.val_b])


def export_excel(diffs: List[DiffResult], output_path: str) -> None:
    wb = openpyxl.Workbook()
    wb.remove(wb.active)

    by_sheet: dict[str, List[DiffResult]] = defaultdict(list)
    for d in diffs:
        by_sheet[d.sheet].append(d)

    for sheet_name, sheet_diffs in by_sheet.items():
        ws = wb.create_sheet(title=sheet_name[:31])

        headers = ["Cell", "File A Value", "File B Value"]
        for col_idx, header in enumerate(headers, 1):
            cell = ws.cell(row=1, column=col_idx, value=header)
            cell.font = _HEADER_FONT
            cell.fill = _HEADER_FILL

        for row_idx, d in enumerate(sheet_diffs, 2):
            ws.cell(row=row_idx, column=1, value=d.cell_addr)
            cell_a = ws.cell(row=row_idx, column=2, value=d.val_a)
            cell_b = ws.cell(row=row_idx, column=3, value=d.val_b)
            cell_a.fill = _RED_FILL
            cell_b.fill = _RED_FILL

        for col in ws.columns:
            max_len = max((len(str(c.value or "")) for c in col), default=0)
            ws.column_dimensions[col[0].column_letter].width = min(max_len + 4, 60)

    wb.save(output_path)
