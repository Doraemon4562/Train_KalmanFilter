from dataclasses import dataclass
from typing import List, Optional, Callable
import openpyxl
from openpyxl.utils import get_column_letter


@dataclass
class DiffResult:
    sheet: str
    row: int
    col: int
    cell_addr: str
    val_a: str
    val_b: str


def _normalize(val) -> str:
    if val is None:
        return ""
    return str(val).strip()


def compare_files(
    path_a: str,
    path_b: str,
    progress_cb: Optional[Callable[[str, int, int], None]] = None,
) -> List[DiffResult]:
    wb_a = openpyxl.load_workbook(path_a, data_only=True, keep_vba=True)
    wb_b = openpyxl.load_workbook(path_b, data_only=True, keep_vba=True)

    sheets_a = set(wb_a.sheetnames)
    sheets_b = set(wb_b.sheetnames)
    all_sheets = sorted(sheets_a | sheets_b)

    diffs: List[DiffResult] = []

    for idx, sheet_name in enumerate(all_sheets):
        if progress_cb:
            progress_cb(sheet_name, idx, len(all_sheets))

        if sheet_name not in sheets_a:
            diffs.append(DiffResult(sheet_name, 0, 0, "N/A", "[Sheet missing]", "[Sheet exists]"))
            continue
        if sheet_name not in sheets_b:
            diffs.append(DiffResult(sheet_name, 0, 0, "N/A", "[Sheet exists]", "[Sheet missing]"))
            continue

        ws_a = wb_a[sheet_name]
        ws_b = wb_b[sheet_name]

        max_row = max(ws_a.max_row or 1, ws_b.max_row or 1)
        max_col = max(ws_a.max_column or 1, ws_b.max_column or 1)

        for row in range(1, max_row + 1):
            for col in range(1, max_col + 1):
                val_a = _normalize(ws_a.cell(row=row, column=col).value)
                val_b = _normalize(ws_b.cell(row=row, column=col).value)

                if val_a != val_b:
                    addr = f"{get_column_letter(col)}{row}"
                    diffs.append(DiffResult(sheet_name, row, col, addr, val_a, val_b))

    wb_a.close()
    wb_b.close()
    return diffs
