import os
import threading
import tkinter as tk
from tkinter import filedialog, messagebox, ttk
from typing import List

from comparator import DiffResult, compare_files
from exporter import export_csv, export_excel

_EXCEL_FILETYPES = [("Excel files", "*.xlsx *.xlsm"), ("All files", "*.*")]


class ExcelCompareApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Excel Compare Tool")
        self.geometry("1100x680")
        self.minsize(800, 500)
        self.resizable(True, True)

        self._diffs: List[DiffResult] = []
        self._build_ui()

    # ─────────────────────────── UI BUILD ────────────────────────────

    def _build_ui(self):
        self._build_file_section()
        self._build_control_bar()
        self._build_progress()
        self._build_filter_bar()
        self._build_table()

    def _build_file_section(self):
        frame = ttk.LabelFrame(self, text="Select Files", padding=(10, 6))
        frame.pack(fill="x", padx=12, pady=(10, 0))
        frame.columnconfigure(1, weight=1)

        self.path_a = tk.StringVar()
        self.path_b = tk.StringVar()

        for row, (label, var) in enumerate(
            [("File A:", self.path_a), ("File B:", self.path_b)]
        ):
            ttk.Label(frame, text=label, width=7).grid(row=row, column=0, sticky="w", pady=3)
            ttk.Entry(frame, textvariable=var).grid(row=row, column=1, sticky="ew", padx=6, pady=3)
            ttk.Button(
                frame, text="Browse", width=8,
                command=lambda v=var: self._browse(v),
            ).grid(row=row, column=2, pady=3)

    def _build_control_bar(self):
        frame = ttk.Frame(self, padding=(12, 8))
        frame.pack(fill="x")

        self._btn_run = ttk.Button(frame, text="▶  Run Compare", command=self._run_compare)
        self._btn_run.pack(side="left")

        self._save_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(
            frame, text="Auto-save result alongside File A", variable=self._save_var
        ).pack(side="left", padx=16)

        self._status_var = tk.StringVar(value="Ready.")
        ttk.Label(frame, textvariable=self._status_var, foreground="#555").pack(side="left")

    def _build_progress(self):
        self._progress = ttk.Progressbar(self, mode="indeterminate", length=0)
        self._progress.pack(fill="x", padx=12, pady=(0, 4))

    def _build_filter_bar(self):
        frame = ttk.Frame(self, padding=(12, 0))
        frame.pack(fill="x")

        ttk.Label(frame, text="Sheet filter:").pack(side="left")

        self._sheet_var = tk.StringVar(value="All")
        self._sheet_combo = ttk.Combobox(
            frame, textvariable=self._sheet_var, state="readonly", width=22
        )
        self._sheet_combo.pack(side="left", padx=6)
        self._sheet_combo.bind("<<ComboboxSelected>>", lambda _: self._apply_filter())

        self._summary_var = tk.StringVar()
        ttk.Label(frame, textvariable=self._summary_var, foreground="#c00").pack(side="left", padx=12)

        ttk.Button(frame, text="Export Excel", command=self._export_excel).pack(side="right", padx=4)
        ttk.Button(frame, text="Export CSV", command=self._export_csv).pack(side="right", padx=4)

    def _build_table(self):
        frame = ttk.Frame(self)
        frame.pack(fill="both", expand=True, padx=12, pady=(6, 12))
        frame.rowconfigure(0, weight=1)
        frame.columnconfigure(0, weight=1)

        cols = ("sheet", "cell", "val_a", "val_b")
        self._tree = ttk.Treeview(frame, columns=cols, show="headings", selectmode="browse")

        self._tree.heading("sheet", text="Sheet")
        self._tree.heading("cell",  text="Cell")
        self._tree.heading("val_a", text="File A Value")
        self._tree.heading("val_b", text="File B Value")

        self._tree.column("sheet", width=140, minwidth=80,  stretch=False)
        self._tree.column("cell",  width=70,  minwidth=50,  stretch=False)
        self._tree.column("val_a", width=420, minwidth=120)
        self._tree.column("val_b", width=420, minwidth=120)

        self._tree.tag_configure("diff",    background="#fff0f0")
        self._tree.tag_configure("missing", background="#fff8dc")

        vsb = ttk.Scrollbar(frame, orient="vertical",   command=self._tree.yview)
        hsb = ttk.Scrollbar(frame, orient="horizontal", command=self._tree.xview)
        self._tree.configure(yscrollcommand=vsb.set, xscrollcommand=hsb.set)

        self._tree.grid(row=0, column=0, sticky="nsew")
        vsb.grid(row=0, column=1, sticky="ns")
        hsb.grid(row=1, column=0, sticky="ew")

        self._tree.bind("<Double-1>", self._on_row_double_click)

    # ─────────────────────────── ACTIONS ─────────────────────────────

    def _browse(self, var: tk.StringVar):
        path = filedialog.askopenfilename(filetypes=_EXCEL_FILETYPES)
        if path:
            var.set(path)

    def _run_compare(self):
        path_a = self.path_a.get().strip()
        path_b = self.path_b.get().strip()

        if not path_a or not path_b:
            messagebox.showwarning("Missing files", "Please select both File A and File B.")
            return
        for label, p in [("File A", path_a), ("File B", path_b)]:
            if not os.path.isfile(p):
                messagebox.showerror("File not found", f"{label} not found:\n{p}")
                return

        self._btn_run.config(state="disabled")
        self._clear_table()
        self._progress.start(12)
        self._status_var.set("Comparing…")

        def worker():
            try:
                def on_progress(sheet_name: str, idx: int, total: int):
                    self.after(
                        0,
                        lambda sn=sheet_name, i=idx, t=total:
                            self._status_var.set(f"Processing sheet '{sn}'  ({i + 1}/{t})"),
                    )

                diffs = compare_files(path_a, path_b, on_progress)
                self.after(0, lambda: self._on_compare_done(diffs))
            except Exception as exc:
                self.after(0, lambda e=exc: self._on_compare_error(str(e)))

        threading.Thread(target=worker, daemon=True).start()

    def _on_compare_done(self, diffs: List[DiffResult]):
        self._progress.stop()
        self._btn_run.config(state="normal")
        self._diffs = diffs

        sheets = sorted({d.sheet for d in diffs})
        self._sheet_combo["values"] = ["All"] + sheets
        self._sheet_var.set("All")

        self._populate_table(diffs)
        self._status_var.set("Done.")

        if self._save_var.get():
            self._auto_save()

    def _on_compare_error(self, msg: str):
        self._progress.stop()
        self._btn_run.config(state="normal")
        self._status_var.set("Error.")
        messagebox.showerror("Compare failed", msg)

    # ─────────────────────────── TABLE ───────────────────────────────

    def _populate_table(self, diffs: List[DiffResult]):
        self._clear_table()
        for d in diffs:
            tag = (
                "missing"
                if "[Sheet missing]" in (d.val_a, d.val_b)
                else "diff"
            )
            self._tree.insert(
                "", "end",
                values=(d.sheet, d.cell_addr, d.val_a, d.val_b),
                tags=(tag,),
            )
        count = len(diffs)
        self._summary_var.set(f"{count} difference{'s' if count != 1 else ''} found")

    def _clear_table(self):
        self._tree.delete(*self._tree.get_children())
        self._summary_var.set("")

    def _apply_filter(self):
        selected = self._sheet_var.get()
        filtered = (
            self._diffs if selected == "All"
            else [d for d in self._diffs if d.sheet == selected]
        )
        self._populate_table(filtered)

    def _on_row_double_click(self, event):
        item = self._tree.identify_row(event.y)
        if not item:
            return
        sheet, cell, val_a, val_b = self._tree.item(item, "values")
        detail = tk.Toplevel(self)
        detail.title(f"Detail — {sheet} {cell}")
        detail.geometry("560x240")
        detail.resizable(False, False)

        pad = {"padx": 12, "pady": 4}
        ttk.Label(detail, text=f"Sheet:  {sheet}   Cell:  {cell}", font=("", 10, "bold")).pack(anchor="w", **pad)
        ttk.Separator(detail, orient="horizontal").pack(fill="x", padx=12)

        for label, val in [("File A:", val_a), ("File B:", val_b)]:
            f = ttk.Frame(detail, padding=(12, 4))
            f.pack(fill="x")
            ttk.Label(f, text=label, width=8, anchor="w").pack(side="left")
            txt = tk.Text(f, height=3, wrap="word", font=("Consolas", 10))
            txt.insert("1.0", val)
            txt.config(state="disabled")
            txt.pack(side="left", fill="x", expand=True)

        ttk.Button(detail, text="Close", command=detail.destroy).pack(pady=8)

    # ─────────────────────────── EXPORT ──────────────────────────────

    def _export_csv(self):
        if not self._diffs:
            messagebox.showinfo("No data", "Run compare first.")
            return
        path = filedialog.asksaveasfilename(
            defaultextension=".csv",
            filetypes=[("CSV file", "*.csv")],
            initialfile="compare_result.csv",
        )
        if path:
            self._do_export(lambda: export_csv(self._diffs, path), path)

    def _export_excel(self):
        if not self._diffs:
            messagebox.showinfo("No data", "Run compare first.")
            return
        path = filedialog.asksaveasfilename(
            defaultextension=".xlsx",
            filetypes=[("Excel file", "*.xlsx")],
            initialfile="compare_result.xlsx",
        )
        if path:
            self._do_export(lambda: export_excel(self._diffs, path), path)

    def _do_export(self, fn, path: str):
        try:
            fn()
            messagebox.showinfo("Saved", f"File saved:\n{path}")
        except Exception as exc:
            messagebox.showerror("Export failed", str(exc))

    def _auto_save(self):
        base = os.path.splitext(self.path_a.get())[0]
        try:
            export_csv(self._diffs,   base + "_compare_result.csv")
            export_excel(self._diffs, base + "_compare_result.xlsx")
            self._status_var.set("Done. Results auto-saved alongside File A.")
        except Exception as exc:
            messagebox.showwarning("Auto-save failed", str(exc))
