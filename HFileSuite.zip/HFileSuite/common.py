# -*- coding: utf-8 -*-
"""Tiện ích dùng chung cho H-File Tool Suite (Module 1 + Module 3)."""
from __future__ import annotations

import io
import json
import os
import platform
import re
import shutil
import subprocess
import zipfile
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Union

# ---------------------------------------------------------------------------
# Regex dùng chung
# ---------------------------------------------------------------------------
NO_SHEET_RE     = re.compile(r"^No(\d+)$", re.IGNORECASE)
IDENT_RE        = re.compile(r"^[A-Za-z_]\w*$")
MULTI_COMMENT_RE = re.compile(r"/\*.*?\*/", re.DOTALL)
LINE_COMMENT_RE  = re.compile(r"//.*$")

# ---------------------------------------------------------------------------
# Excel constants dùng chung
# ---------------------------------------------------------------------------
DEFAULT_SHEET_NAME  = "操作"
MEMBER_DISABLE_MARK = "/*"

# ---------------------------------------------------------------------------
# UI Palette & Fonts (dùng trong tất cả GUI file)
# ---------------------------------------------------------------------------
PALETTE: Dict[str, str] = {
    "navy":      "#1B2A4A",
    "blue":      "#2563EB",
    "blue_lt":   "#3B82F6",
    "green":     "#16A34A",
    "amber":     "#D97706",
    "red":       "#DC2626",
    "bg":        "#F1F5F9",
    "surface":   "#FFFFFF",
    "border":    "#CBD5E1",
    "text":      "#1E293B",
    "muted":     "#64748B",
    "row_ok":    "#DCFCE7",
    "row_warn":  "#FEF3C7",
    "row_err":   "#FEE2E2",
    "row_cache": "#FED7AA",
    "header_fg": "#F8FAFC",
    "header_sub":"#94A3B8",
}

FONT_UI   = ("Segoe UI", 9)
FONT_BOLD = ("Segoe UI", 9,  "bold")
FONT_MONO = ("Consolas",  9)
FONT_HEAD = ("Segoe UI", 13, "bold")


# ---------------------------------------------------------------------------
# File I/O helpers
# ---------------------------------------------------------------------------

def read_text_auto(path: Path) -> Tuple[str, str]:
    """Đọc file với fallback encoding: BOM → UTF-8 → CP932 → latin-1."""
    data = path.read_bytes()
    if data.startswith(b"\xef\xbb\xbf"):
        return data.decode("utf-8-sig", errors="replace"), "utf-8-sig"
    if data.startswith(b"\xff\xfe") or data.startswith(b"\xfe\xff"):
        return data.decode("utf-16", errors="replace"), "utf-16"
    for enc in ("utf-8", "cp932", "shift_jis", "latin-1"):
        try:
            return data.decode(enc), enc
        except UnicodeDecodeError:
            continue
    return data.decode("utf-8", errors="replace"), "utf-8-replace"


def load_cache(path: Path) -> Dict[str, str]:
    if not path.exists():
        return {}
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        if isinstance(data, dict):
            return {str(k): str(v) for k, v in data.items()}
    except Exception:
        pass
    return {}


def save_cache(path: Path, cache: Dict[str, str]) -> None:
    path.write_text(json.dumps(cache, ensure_ascii=False, indent=2), encoding="utf-8")


def make_backup(xlsm_path: Path) -> Path:
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup = xlsm_path.with_name(
        "{}_backup_{}{}".format(xlsm_path.stem, timestamp, xlsm_path.suffix)
    )
    shutil.copy2(str(xlsm_path), str(backup))
    return backup


def open_path_in_os(path: Union[str, Path]) -> None:
    p = str(path)
    try:
        if platform.system() == "Windows":
            os.startfile(p)  # type: ignore[attr-defined]
        elif platform.system() == "Darwin":
            subprocess.Popen(["open", p])
        else:
            subprocess.Popen(["xdg-open", p])
    except Exception:
        pass


def script_dir() -> Path:
    try:
        return Path(__file__).resolve().parent
    except NameError:
        return Path.cwd()


# ---------------------------------------------------------------------------
# openpyxl Drawing Preservation
# ---------------------------------------------------------------------------

# Tags openpyxl strips from sheet XML when saving
_DRAW_TAG_RE = re.compile(
    r'<(?:\w+:)?(?:drawing|legacyDrawing|legacyDrawingHF|picture)(?:\s[^>]*)?\s*/>',
    re.IGNORECASE,
)
_DRAWING_DIRS = ('xl/drawings/', 'xl/media/', 'xl/activeX/', 'xl/ctrlProps/')
_CT_OVERRIDE_RE = re.compile(r'<Override\s+[^/]*/>', re.IGNORECASE)
_CT_DRAWING_RE  = re.compile(r'drawing|activeX|media', re.I)


def save_workbook_preserve_drawings(wb, original_path: Path, save_path: Optional[Path] = None) -> None:
    """Save openpyxl workbook while preserving shapes/drawings from the original file.

    openpyxl drops xl/drawings, xl/media, legacyDrawing refs, and sheet .rels
    that reference drawings when it saves. This function merges the new workbook
    data with the drawing entries read from the still-unmodified original on disk.
    """
    if save_path is None:
        save_path = original_path

    # --- Step 1: save with openpyxl ---
    buf = io.BytesIO()
    wb.save(buf)
    new_bytes = buf.getvalue()

    # --- Step 2: collect drawing-related entries from original ---
    extra: Dict[str, bytes] = {}          # drawing/media files to copy verbatim
    sheet_rels: Dict[str, bytes] = {}     # sheet .rels that reference drawings
    sheet_frags: Dict[str, List[str]] = {}  # sheet path → drawing element strings
    orig_ct: bytes = b''                  # original [Content_Types].xml

    try:
        with zipfile.ZipFile(str(original_path), 'r') as zin:
            for name in zin.namelist():
                data = zin.read(name)
                if any(name.startswith(d) for d in _DRAWING_DIRS):
                    extra[name] = data
                elif name == '[Content_Types].xml':
                    orig_ct = data
                elif name.startswith('xl/worksheets/_rels/') and name.endswith('.rels'):
                    if re.search(r'drawing|activeX', data.decode('utf-8', errors='replace'), re.I):
                        sheet_rels[name] = data
                elif name.startswith('xl/worksheets/') and name.endswith('.xml'):
                    txt = data.decode('utf-8', errors='replace')
                    frags = _DRAW_TAG_RE.findall(txt)
                    if frags:
                        sheet_frags[name] = frags
    except Exception:
        save_path.write_bytes(new_bytes)
        return

    if not extra and not sheet_rels:
        save_path.write_bytes(new_bytes)
        return

    # --- Step 3: merge ---
    out = io.BytesIO()
    with zipfile.ZipFile(io.BytesIO(new_bytes), 'r') as znew, \
         zipfile.ZipFile(out, 'w', zipfile.ZIP_DEFLATED) as zout:

        written: set = set()

        for name in znew.namelist():
            if name in sheet_rels:
                data = sheet_rels[name]
            elif name in extra:
                data = extra[name]
            elif name in sheet_frags:
                raw = znew.read(name).decode('utf-8', errors='replace')
                raw = _DRAW_TAG_RE.sub('', raw)
                inject = '\n'.join(sheet_frags[name])
                raw = re.sub(r'(</(?:\w+:)?worksheet>)', inject + '\n' + r'\1', raw)
                data = raw.encode('utf-8')
            elif name == '[Content_Types].xml' and orig_ct:
                data = _merge_content_types(znew.read(name), orig_ct)
            else:
                data = znew.read(name)

            zout.writestr(name, data)
            written.add(name)

        # drawing files that openpyxl omitted entirely
        for name, data in {**extra, **sheet_rels}.items():
            if name not in written:
                zout.writestr(name, data)

    save_path.write_bytes(out.getvalue())


def _merge_content_types(new_ct_bytes: bytes, orig_ct_bytes: bytes) -> bytes:
    """Add drawing/media Override entries from original into new [Content_Types].xml."""
    new_ct = new_ct_bytes.decode('utf-8', errors='replace')
    orig_ct = orig_ct_bytes.decode('utf-8', errors='replace')
    existing = set(_CT_OVERRIDE_RE.findall(new_ct))
    to_add = [
        o for o in _CT_OVERRIDE_RE.findall(orig_ct)
        if o not in existing and _CT_DRAWING_RE.search(o)
    ]
    if to_add:
        new_ct = new_ct.replace('</Types>', '\n'.join(to_add) + '\n</Types>')
    return new_ct.encode('utf-8')
